#!/usr/bin/env node

/**
 * Script de Teste de Cabeçalhos HTTP - RDS Topografia
 * 
 * Este script testa os cabeçalhos HTTP do site para verificar
 * se há bloqueio de indexação via X-Robots-Tag
 * 
 * Uso: node test-headers.js
 */

const https = require('https');

const URL = 'https://rdstopografia.com.br';

console.log('\n🔍 Testando Cabeçalhos HTTP do Site RDS Topografia\n');
console.log('=' .repeat(60));
console.log(`URL: ${URL}`);
console.log('=' .repeat(60) + '\n');

const options = {
  method: 'HEAD',
  headers: {
    'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
  }
};

https.get(URL, options, (res) => {
  console.log('📊 STATUS DA RESPOSTA:\n');
  console.log(`   Status Code: ${res.statusCode} ${res.statusMessage}`);
  console.log(`   HTTP Version: ${res.httpVersion}\n`);
  
  console.log('📋 CABEÇALHOS RELEVANTES:\n');
  
  // Verificar X-Robots-Tag (crítico!)
  const xRobotsTag = res.headers['x-robots-tag'];
  if (xRobotsTag) {
    if (xRobotsTag.includes('noindex')) {
      console.log('   ❌ X-Robots-Tag: ' + xRobotsTag);
      console.log('   🚨 PROBLEMA ENCONTRADO: noindex detectado!\n');
    } else {
      console.log('   ✅ X-Robots-Tag: ' + xRobotsTag);
      console.log('   ✓ Permite indexação\n');
    }
  } else {
    console.log('   ℹ️  X-Robots-Tag: Não definido');
    console.log('   ✓ Sem bloqueio explícito (OK)\n');
  }
  
  // Outros cabeçalhos importantes
  const relevantHeaders = [
    'content-type',
    'cache-control',
    'server',
    'x-powered-by',
    'content-security-policy'
  ];
  
  relevantHeaders.forEach(header => {
    if (res.headers[header]) {
      console.log(`   ${header}: ${res.headers[header]}`);
    }
  });
  
  console.log('\n' + '='.repeat(60));
  console.log('📊 ANÁLISE:\n');
  
  // Análise final
  if (xRobotsTag && xRobotsTag.includes('noindex')) {
    console.log('❌ PROBLEMA CRÍTICO DETECTADO!');
    console.log('\nO servidor está enviando cabeçalho X-Robots-Tag com "noindex".');
    console.log('Isso está bloqueando a indexação pelo Google.\n');
    console.log('🔧 SOLUÇÕES:');
    console.log('   1. Faça upload do arquivo /public/.htaccess para o servidor');
    console.log('   2. Ou entre em contato com suporte do hosting');
    console.log('   3. Veja /GUIA_CORRECAO_POR_HOSTING.md para detalhes\n');
  } else if (xRobotsTag && xRobotsTag.includes('index')) {
    console.log('✅ CABEÇALHO CORRETO!');
    console.log('\nO servidor está permitindo indexação via X-Robots-Tag.\n');
    console.log('🎯 PRÓXIMOS PASSOS:');
    console.log('   1. Solicite re-rastreamento no Google Search Console');
    console.log('   2. Aguarde 24-48 horas para processamento');
    console.log('   3. Verifique status de indexação novamente\n');
  } else {
    console.log('ℹ️  SEM CABEÇALHO X-ROBOTS-TAG');
    console.log('\nO servidor não está enviando cabeçalho X-Robots-Tag.');
    console.log('Isso é normal e permite indexação.\n');
    console.log('🔍 VERIFICAÇÃO ADICIONAL NECESSÁRIA:');
    console.log('   1. Acesse: https://rdstopografia.com.br/diagnostico-noindex.html');
    console.log('   2. Execute todos os testes');
    console.log('   3. Verifique se meta tags HTML estão corretas\n');
  }
  
  console.log('='.repeat(60) + '\n');
  
  // Mostrar todos cabeçalhos para debug
  console.log('🔬 TODOS OS CABEÇALHOS (para debug):\n');
  Object.keys(res.headers).forEach(header => {
    console.log(`   ${header}: ${res.headers[header]}`);
  });
  
  console.log('\n' + '='.repeat(60));
  console.log('✅ Teste concluído!\n');
  
}).on('error', (err) => {
  console.error('\n❌ ERRO ao conectar ao servidor:\n');
  console.error(`   ${err.message}\n`);
  console.log('🔧 POSSÍVEIS CAUSAS:');
  console.log('   1. Site está offline');
  console.log('   2. Problemas de DNS');
  console.log('   3. Firewall bloqueando conexão');
  console.log('   4. Certificado SSL inválido\n');
  console.log('💡 TENTE:');
  console.log('   1. Acessar o site no navegador');
  console.log('   2. Verificar se domínio está configurado corretamente');
  console.log('   3. Aguardar alguns minutos e tentar novamente\n');
});
