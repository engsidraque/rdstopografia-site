# Guia Rápido de Teste - Acessibilidade RDS Topografia

**Versão**: 2.0  
**Data**: 05/03/2026

---

## 🧪 Testes Manuais (5 minutos)

### ✅ Navegação por Teclado

#### Teste 1: Skip Link
1. Recarregue a página (Ctrl/Cmd + R)
2. Pressione **Tab** uma vez
3. **Resultado esperado**: Botão vermelho "Pular para o conteúdo principal" aparece no topo esquerdo
4. Pressione **Enter**
5. **Resultado esperado**: Scroll para o conteúdo principal (pula header)

#### Teste 2: Menu Desktop
1. Continue pressionando **Tab**
2. **Resultado esperado**: 
   - Logo → Links de navegação → Botão "Orçamento" → Telefones
   - Link ativo tem indicador visual diferente
   - Focus ring visível em todos os elementos

#### Teste 3: Menu Mobile
1. Redimensione janela para < 768px (ou use DevTools Device Toolbar)
2. Pressione **Tab** até o botão hamburger (☰)
3. Pressione **Enter** para abrir menu
4. **Resultado esperado**: Menu abre e body não rola
5. Pressione **Esc**
6. **Resultado esperado**: Menu fecha
7. Abra menu novamente
8. Navegue com **Tab** pelos links
9. Pressione **Enter** em qualquer link
10. **Resultado esperado**: Navega e fecha menu automaticamente

#### Teste 4: Scroll to Top
1. Role a página até o final
2. **Resultado esperado**: Botão cinza com seta ↑ aparece (bottom: 24px, right: 24px)
3. Pressione **Tab** até focar o botão
4. **Resultado esperado**: Focus ring visível
5. Pressione **Enter**
6. **Resultado esperado**: Scroll suave até o topo

#### Teste 5: WhatsApp Button
1. Role página até aparecer botão WhatsApp verde (fixo)
2. Pressione **Tab** até focar
3. **Resultado esperado**: Focus ring verde visível
4. Tooltip "Fale conosco no WhatsApp" aparece

---

## 🎤 Testes com Leitor de Tela

### macOS - VoiceOver

#### Ativar
```bash
Cmd + F5
```

#### Teste Básico
1. Abra a página inicial
2. VoiceOver deve anunciar: "RDS Topografia - Serviços de Topografia..."
3. Pressione **Cmd + L** (navegar por links)
4. **Resultado esperado**: 
   - "Link, Pular para o conteúdo principal"
   - "Link, RDS Topografia, imagem"
   - "Link, Início, você está aqui" (se estiver em /)
   - "Botão, Orçamento"

5. Pressione **Cmd + H** (navegar por headings)
6. **Resultado esperado**: Lê todos os headings em ordem hierárquica

#### Testar ARIA
```
Control + Option + U = Rotor de elementos
- Links: Todos devem ter labels descritivos
- Headings: Hierarquia correta (h1 → h2 → h3)
- Landmarks: header, main, nav, footer, contentinfo
```

### Windows - NVDA (Free)

#### Instalar
```
https://www.nvaccess.org/download/
```

#### Ativar
```
Ctrl + Alt + N
```

#### Teste Básico
1. Abra a página inicial
2. Pressione **Insert + Down** (modo de navegação)
3. Use **H** para navegar por headings
4. Use **K** para navegar por links
5. Use **B** para navegar por botões
6. **Resultado esperado**: NVDA anuncia corretamente cada elemento

---

## 🔍 Testes Automatizados

### 1. Lighthouse (Chrome DevTools)

#### Executar
```
1. Abrir Chrome DevTools (F12)
2. Aba "Lighthouse"
3. Selecionar:
   ✅ Performance
   ✅ Accessibility
   ✅ Best Practices
   ✅ SEO
4. Device: Mobile + Desktop (testar ambos)
5. Clicar "Analyze page load"
```

#### Resultado Esperado (Desktop)
```
✅ Performance: 90-100
✅ Accessibility: 95-100
✅ Best Practices: 95-100
✅ SEO: 95-100
```

#### Resultado Esperado (Mobile)
```
✅ Performance: 85-95
✅ Accessibility: 95-100
✅ Best Practices: 95-100
✅ SEO: 95-100
```

### 2. axe DevTools (Chrome Extension)

#### Instalar
```
https://chrome.google.com/webstore/detail/axe-devtools-web-accessibility-testing/lhdoppojpmngadmnindnejefpokejbdd
```

#### Executar
```
1. Abrir Chrome DevTools (F12)
2. Aba "axe DevTools"
3. Clicar "Scan ALL of my page"
4. Aguardar análise
```

#### Resultado Esperado
```
✅ Issues: 0 Critical
✅ Issues: 0 Serious
⚠️  Issues: 0-2 Moderate (aceitável)
ℹ️  Issues: 0-5 Minor (aceitável)

Score: 95-100/100
```

### 3. WAVE (Web Extension)

#### Instalar
```
https://wave.webaim.org/extension/
```

#### Executar
```
1. Abrir qualquer página do site
2. Clicar ícone WAVE na toolbar
3. Revisar painel lateral
```

#### Resultado Esperado
```
✅ Errors: 0
✅ Contrast Errors: 0
⚠️  Alerts: 0-3 (warnings aceitáveis)
✅ Features: 15+ (ARIA labels, landmarks, etc.)
✅ Structural Elements: Corretos
```

---

## 📱 Testes Mobile

### 1. Chrome DevTools Device Simulation

#### Dispositivos para Testar
```
✅ iPhone SE (375x667) - Menor tela moderna
✅ iPhone 12 Pro (390x844) - Padrão atual
✅ Samsung Galaxy S20 (360x800) - Android
✅ iPad Mini (768x1024) - Tablet
✅ iPad Pro (1024x1366) - Tablet grande
```

#### Checklist por Dispositivo
```
[ ] Menu hamburger aparece e funciona
[ ] Logo tem tamanho adequado (h-20 = 80px)
[ ] Botões têm área de toque mínima 44x44px
[ ] Textos são legíveis (mínimo 16px)
[ ] WhatsApp button não sobrepõe conteúdo
[ ] Scroll to top button não sobrepõe WhatsApp
[ ] Menu mobile não permite scroll da página quando aberto
[ ] Todos os links são clicáveis (não muito próximos)
```

### 2. Teste em Dispositivo Real

#### iPhone/iPad (Safari)
```
1. Conectar dispositivo ao Mac
2. Safari > Develop > [Seu iPhone] > [Página]
3. Usar Web Inspector para debug
```

#### Android (Chrome)
```
1. Ativar "Depuração USB" nas Opções do desenvolvedor
2. Conectar ao computador
3. chrome://inspect#devices
4. Clicar "Inspect" na página desejada
```

#### Checklist
```
[ ] Touch targets são grandes o suficiente
[ ] Scroll é suave
[ ] Menu abre/fecha suavemente
[ ] Sem erros no console
[ ] Fontes carregam corretamente
[ ] Imagens WebP funcionam
```

---

## 🎨 Testes de Contraste

### Ferramenta Online
```
https://webaim.org/resources/contrastchecker/
```

### Cores RDS para Testar

#### 1. Texto principal (Preto sobre Branco)
```
Foreground: #374151 (gray-700)
Background: #FFFFFF (white)
Ratio: 10.82:1
✅ WCAG AA: Pass (mínimo 4.5:1)
✅ WCAG AAA: Pass (mínimo 7:1)
```

#### 2. CTA Vermelho (Branco sobre Vermelho)
```
Foreground: #FFFFFF (white)
Background: #DC2626 (red-600)
Ratio: 5.47:1
✅ WCAG AA: Pass (mínimo 4.5:1)
⚠️  WCAG AAA: Fail (mínimo 7:1) - Aceitável para botões
```

#### 3. Links Vermelho (Vermelho sobre Branco)
```
Foreground: #DC2626 (red-600)
Background: #FFFFFF (white)
Ratio: 5.47:1
✅ WCAG AA: Pass
```

#### 4. Texto Cinza (Gray-600 sobre Branco)
```
Foreground: #4B5563 (gray-600)
Background: #FFFFFF (white)
Ratio: 8.59:1
✅ WCAG AA: Pass
✅ WCAG AAA: Pass
```

---

## ⌨️ Atalhos de Teclado (Implementados)

| Tecla | Ação | Contexto |
|-------|------|----------|
| **Tab** | Próximo elemento focável | Global |
| **Shift + Tab** | Elemento anterior | Global |
| **Enter** | Ativa link/botão | Elemento focado |
| **Espaço** | Ativa botão | Botão focado |
| **Esc** | Fecha menu mobile | Menu aberto |
| **Home** | Topo da página | Global (nativo) |
| **End** | Final da página | Global (nativo) |

---

## 🐛 Bugs Comuns e Como Testar

### Bug 1: Menu Mobile não fecha com Esc
**Teste**: Abrir menu → Pressionar Esc  
**Esperado**: Menu fecha  
**Verificar**: `Header.tsx` linha ~14 (useEffect com handleEscape)

### Bug 2: Scroll da página acontece com menu aberto
**Teste**: Abrir menu mobile → Tentar rolar página  
**Esperado**: Página não rola  
**Verificar**: `Header.tsx` linha ~27 (useEffect com overflow: hidden)

### Bug 3: Skip link não aparece ao pressionar Tab
**Teste**: Recarregar página → Pressionar Tab  
**Esperado**: Link vermelho aparece no topo  
**Verificar**: Classes CSS `.sr-only .focus:not-sr-only`

### Bug 4: Focus ring invisível
**Teste**: Tab em qualquer botão/link  
**Esperado**: Borda visível ao redor do elemento  
**Verificar**: Classes `focus:ring-*` ou `focus:outline-*`

### Bug 5: Scroll to Top não aparece
**Teste**: Rolar página > 400px  
**Esperado**: Botão cinza com seta aparece  
**Verificar**: `ScrollToTop.tsx` linha ~9 (useState e useEffect)

---

## 📊 Relatório de Teste

### Template de Relatório

```markdown
# Teste de Acessibilidade - RDS Topografia
**Data**: ___________
**Testador**: ___________
**Navegador**: ___________ (versão)
**Dispositivo**: ___________

## Navegação por Teclado
- [ ] Skip link funciona
- [ ] Tab navega em ordem lógica
- [ ] Focus ring visível em todos os elementos
- [ ] Menu mobile abre/fecha com Enter
- [ ] Menu mobile fecha com Esc
- [ ] Scroll to top funciona com Enter

## Leitor de Tela
**Ferramenta**: ___________ (NVDA/VoiceOver)
- [ ] Skip link é anunciado
- [ ] Links têm labels descritivos
- [ ] Botões têm labels descritivos
- [ ] Landmarks são identificados (header, main, nav, footer)
- [ ] Headings em ordem hierárquica

## Ferramentas Automatizadas
**Lighthouse Accessibility**: _____ / 100
**axe DevTools**: _____ issues (_____ críticos)
**WAVE**: _____ erros, _____ alertas

## Mobile
**Dispositivo testado**: ___________
- [ ] Menu hamburger funciona
- [ ] Área de toque adequada (44x44px mínimo)
- [ ] Textos legíveis
- [ ] Scroll suave
- [ ] Sem scroll com menu aberto

## Contraste
- [ ] Texto principal: Pass WCAG AA
- [ ] CTAs vermelho: Pass WCAG AA
- [ ] Links: Pass WCAG AA

## Observações
___________________________________________
___________________________________________
___________________________________________

## Resultado Final
[ ] ✅ Aprovado
[ ] ⚠️  Aprovado com ressalvas
[ ] ❌ Reprovado

**Assinatura**: ___________
```

---

## 🎯 Checklist Rápido (1 minuto)

Para teste diário rápido:

```
[ ] Tab → Skip link aparece
[ ] Tab → Navegação funciona
[ ] Resize para mobile → Menu hamburger aparece
[ ] Abrir menu mobile → Funciona
[ ] Esc → Menu fecha
[ ] Scroll down → Scroll to top aparece
[ ] F12 → Console sem erros
[ ] Lighthouse → Score > 90
```

---

## 📞 Suporte

### Problemas de Acessibilidade
- Revisar `/MELHORIAS_ACESSIBILIDADE_UX.md`
- Verificar conformidade WCAG 2.1 AA

### Problemas de Performance
- Revisar `/OTIMIZACOES_PERFORMANCE.md`
- Verificar lazy loading e code splitting

### Problemas de SEO
- Revisar `/SEO_CORRECOES.md`
- Verificar schema markup e meta tags

---

**Última atualização**: 05/03/2026  
**Versão do guia**: 1.0  
**Aplicável à versão**: RDS Topografia 2.0+
