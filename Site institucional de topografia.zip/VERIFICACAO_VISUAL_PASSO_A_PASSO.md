# 👁️ VERIFICAÇÃO VISUAL - PASSO A PASSO COM IMAGENS

## 🎯 OBJETIVO

Ensinar como verificar visualmente se o problema de "noindex" foi resolvido usando as DevTools do navegador.

---

## 🖥️ MÉTODO 1: CHROME / EDGE (RECOMENDADO)

### PASSO 1: Abrir o Site
```
https://rdstopografia.com.br
```

### PASSO 2: Abrir DevTools

**Opção A - Atalho de teclado:**
- Windows/Linux: `F12` ou `Ctrl + Shift + I`
- Mac: `Cmd + Option + I`

**Opção B - Menu:**
- Clique com botão direito → "Inspecionar" ou "Inspect"
- Ou: Menu (3 pontos) → Mais ferramentas → Ferramentas do desenvolvedor

### PASSO 3: Ir para Elements/Elementos

Na barra superior das DevTools, clique em:
```
Elements (Chrome em inglês)
Elementos (Chrome em português)
```

### PASSO 4: Navegar até o <head>

Na estrutura HTML à esquerda, você verá:
```html
<!DOCTYPE html>
<html>
  <head>    ← Clique aqui para expandir
    ...
  </head>
  <body>
    ...
  </body>
</html>
```

Clique na setinha ao lado de `<head>` para expandir.

### PASSO 5: Procurar por Meta Robots

**Opção A - Buscar:**
- Pressione `Ctrl + F` (Windows/Linux) ou `Cmd + F` (Mac)
- Digite: `robots`
- Navegue pelos resultados com as setas

**Opção B - Rolar manualmente:**
- Role dentro do `<head>` até encontrar as meta tags

### PASSO 6: VERIFICAR ✅ ou ❌

#### ✅ CORRETO - Deve aparecer assim:

```html
<meta name="robots" content="index, follow, max-snippet:-1, 
  max-image-preview:large, max-video-preview:-1">
```

**Características:**
- ✅ Apenas UMA tag `meta name="robots"`
- ✅ Content contém `"index, follow"`
- ✅ NÃO contém `"noindex"`
- ✅ NÃO tem IDs estranhos

#### ❌ ERRADO - Se aparecer assim:

```html
<meta name="robots" content="noindex">
<meta id="meta-pubwh" name="robots" content="noindex">
<meta id="meta-lalhua" name="robots" content="noindex">
```

**Características do problema:**
- ❌ Múltiplas tags `meta name="robots"`
- ❌ Alguma contém `"noindex"`
- ❌ Tags com IDs estranhos (`meta-pubwh`, etc.)

---

## 🦊 MÉTODO 2: FIREFOX

### PASSO 1-2: Igual ao Chrome
```
https://rdstopografia.com.br
F12 ou Ctrl + Shift + I
```

### PASSO 3: Ir para Inspector

Na barra superior, clique em:
```
Inspector (Firefox em inglês)
Inspetor (Firefox em português)
```

### PASSO 4-6: Igual ao Chrome
- Expandir `<head>`
- Buscar por `robots` (Ctrl+F)
- Verificar content

---

## 🧪 MÉTODO 3: SAFARI (MAC)

### PASSO 1: Habilitar Menu Desenvolvedor (primeira vez)

1. Safari → Preferências → Avançado
2. Marcar: "Mostrar menu Desenvolver na barra de menus"

### PASSO 2: Abrir Web Inspector

- Atalho: `Cmd + Option + I`
- Ou: Menu Desenvolvedor → Mostrar Web Inspector

### PASSO 3-6: Igual aos outros
- Aba "Elementos"
- Expandir `<head>`
- Buscar `robots`

---

## 🔍 MÉTODO 4: VISUALIZAR CÓDIGO FONTE

### Qualquer Navegador:

**PASSO 1:** Acesse o site

**PASSO 2:** Ver código fonte
- Windows/Linux: `Ctrl + U`
- Mac: `Cmd + Option + U`
- Ou: Botão direito → "Ver código da página"

**PASSO 3:** Buscar
- `Ctrl + F` ou `Cmd + F`
- Digite: `robots`

**PASSO 4:** Verificar
- ✅ Deve ter: `content="index, follow"`
- ❌ NÃO deve ter: `content="noindex"`

**VANTAGEM:** Mostra o HTML puro sem modificações do React  
**DESVANTAGEM:** Pode ser difícil de ler (HTML minificado)

---

## 📱 MÉTODO 5: MOBILE (CELULAR)

### Android - Chrome:

1. Acesse `https://rdstopografia.com.br`
2. Menu (3 pontos) → "Versão para computador"
3. Menu (3 pontos) → "Mais ferramentas" → "Ver código-fonte"
4. Busque por `robots` (use busca do navegador)

### iPhone - Safari:

**Opção A - Ferramenta Online:**
```
https://search.google.com/test/mobile-friendly
```
Cole: `https://rdstopografia.com.br`

**Opção B - Ver no Mac:**
1. Conecte iPhone ao Mac via cabo
2. Safari no Mac → Desenvolver → [Seu iPhone] → [Página]

---

## 🛠️ MÉTODO 6: FERRAMENTAS ONLINE

### 1. Google Mobile-Friendly Test
```
https://search.google.com/test/mobile-friendly
```
- Cole URL: `https://rdstopografia.com.br`
- Aguarde carregar
- Clique em "Ver código testado"
- Busque por `robots`

### 2. Google Search Console
```
https://search.google.com/search-console
```
- Inspeção de URL
- Cole: `https://rdstopografia.com.br`
- Clique "Testar URL ativo"
- Aguarde resultado
- Veja detalhes da renderização

### 3. Ferramenta Própria do Site
```
https://rdstopografia.com.br/teste-indexacao.html
```
- Carrega automaticamente
- Mostra resultado colorido
- Indica erros claramente

### 4. cURL (Terminal/CMD)

**Windows (PowerShell):**
```powershell
Invoke-WebRequest -Uri https://rdstopografia.com.br `
  -UseBasicParsing | Select-Object -ExpandProperty Headers
```

**Mac/Linux (Terminal):**
```bash
curl -I https://rdstopografia.com.br | grep -i robots
```

**Resultado esperado:**
```
x-robots-tag: index, follow, max-snippet:-1, 
  max-image-preview:large, max-video-preview:-1
```

---

## 📊 COMPARAÇÃO DOS MÉTODOS

| Método | Facilidade | Precisão | Velocidade |
|--------|-----------|----------|------------|
| **DevTools (Chrome)** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **Código Fonte** | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **Mobile** | ⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ |
| **Google Tools** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Ferramenta Site** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **cURL** | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |

**RECOMENDADO PARA VOCÊ:**
1. 🥇 Ferramenta do site (`/teste-indexacao.html`)
2. 🥈 DevTools do Chrome
3. 🥉 Google Search Console

---

## 🎓 ENTENDENDO O QUE VER

### Meta Tag Robots - Anatomia

```html
<meta name="robots" content="index, follow, max-snippet:-1, 
  max-image-preview:large, max-video-preview:-1">
```

**Partes:**
- `name="robots"` → Indica que é para robôs de busca
- `content="..."` → Instruções para os robôs

**Valores do content:**

| Valor | Significado |
|-------|-------------|
| `index` | ✅ Permitir indexação |
| `noindex` | ❌ BLOQUEAR indexação |
| `follow` | ✅ Seguir links da página |
| `nofollow` | ⚠️ Não seguir links |
| `max-snippet:-1` | Sem limite de snippet |
| `max-image-preview:large` | Permitir preview grande de imagem |
| `max-video-preview:-1` | Sem limite de preview de vídeo |

### ✅ VALORES CORRETOS (O que você QUER ver):
- `index, follow`
- `all` (equivalente a index, follow)
- `index, follow, max-snippet:-1, ...`

### ❌ VALORES INCORRETOS (O que você NÃO quer ver):
- `noindex`
- `noindex, nofollow`
- `none` (equivalente a noindex, nofollow)

---

## 🚨 PROBLEMAS COMUNS E SOLUÇÕES

### Problema 1: Vejo "index" E "noindex" ao mesmo tempo

```html
<meta name="robots" content="index, follow">
<meta name="robots" content="noindex">  ← Problema!
```

**Causa:** Tags duplicadas  
**Efeito:** Google usa a mais restritiva (noindex)  
**Solução:** Remover tag com noindex do código fonte

---

### Problema 2: Tag correta mas Google ainda bloqueia

**Causa:** Cache do Google  
**Solução:**
1. Google Search Console → Inspeção de URL
2. "Testar URL ativo" (testa versão atual)
3. "Solicitar indexação"
4. Aguardar 24-48h

---

### Problema 3: DevTools mostra correto mas código fonte não

**Causa:** React está substituindo tag incorreta  
**Efeito:** Google vê a tag incorreta (do HTML base)  
**Solução:** Verificar `index.html` do servidor

---

### Problema 4: Tudo correto localmente, mas erro em produção

**Causa:** Arquivo `index.html` diferente no servidor  
**Solução:**
1. Compare `index.html` local vs. servidor
2. Re-faça deploy completo
3. Limpe cache do servidor

---

## 📸 CAPTURAS DE TELA (TEXTO DESCRITIVO)

### Como DEVE aparecer no DevTools:

```
Elements
└─ html
   └─ head
      ├─ meta charset="UTF-8"
      ├─ meta name="viewport" content="..."
      ├─ meta name="robots" content="index, follow, ..."  ← ISSO!
      ├─ title ← Título da página
      ├─ meta name="description" content="..."
      └─ link rel="canonical" href="https://..."
```

**Destaque visual:**
- Uma linha destacada com `name="robots"`
- Content começando com `"index, follow"`
- SEM outras linhas com `name="robots"`

---

### Como NÃO deve aparecer:

```
Elements
└─ html
   └─ head
      ├─ meta name="robots" content="noindex"           ← ERRO!
      ├─ meta id="meta-pubwh" name="robots" content="noindex"  ← ERRO!
      ├─ meta id="meta-lalhua" name="robots" content="noindex" ← ERRO!
```

**Sinais de problema:**
- Múltiplas linhas com `name="robots"`
- Qualquer uma contendo `"noindex"`
- IDs estranhos nas tags

---

## ✅ CHECKLIST DE VERIFICAÇÃO

Use esta checklist ao verificar visualmente:

### Verificação Básica:
- [ ] Consegui abrir DevTools
- [ ] Encontrei a seção `<head>`
- [ ] Localizei `<meta name="robots">`

### Verificação de Conteúdo:
- [ ] Content contém "index"
- [ ] Content contém "follow"
- [ ] Content NÃO contém "noindex"
- [ ] Content NÃO contém "nofollow"

### Verificação de Duplicatas:
- [ ] Existe apenas UMA tag robots
- [ ] Nenhuma tag tem ID estranho
- [ ] Todas as outras meta tags estão OK

### Verificação Complementar:
- [ ] Tag `<title>` existe e tem conteúdo
- [ ] Tag `<meta name="description">` existe
- [ ] Tag `<link rel="canonical">` existe
- [ ] URL canônica contém domínio correto

### Verificação Final:
- [ ] Testei em modo normal
- [ ] Testei em modo anônimo (cache limpo)
- [ ] Testei em outro navegador
- [ ] Ferramenta `/teste-indexacao.html` passou

---

## 🎯 QUANDO CONSIDERAR OK

Considere a verificação bem-sucedida quando:

1. ✅ DevTools mostra `index, follow` (sem noindex)
2. ✅ Código fonte mostra mesmo resultado
3. ✅ Ferramenta `/teste-indexacao.html` mostra sucesso
4. ✅ Teste em modo anônimo confirma resultado
5. ✅ Google Search Console "Testar URL ativo" passa

**SE TODOS OS 5 ITENS PASSAREM:**
🎉 **Perfeito! Site configurado corretamente!**

**Próximo passo:**
→ Solicitar indexação no Google Search Console  
→ Aguardar 24-48 horas

---

## 💡 DICAS PRO

### Dica 1: Use Modo Anônimo
Sempre teste também em modo anônimo para garantir que não está vendo cache do navegador.

### Dica 2: Compare com Concorrente
Abra DevTools em um site concorrente que está indexado e compare as meta tags.

### Dica 3: Tire Screenshots
Tire prints das DevTools mostrando as tags corretas. Útil para comparar depois ou enviar ao suporte.

### Dica 4: Documente
Anote a data e hora que verificou. Se precisar abrir ticket no suporte, você terá o histórico.

### Dica 5: Teste Múltiplas Páginas
Não teste só a home. Verifique também:
- `/levantamento-topografico`
- `/locacao-de-obra`
- `/georreferenciamento`
- `/topografia-usucapiao-regularizacao`

---

## 📞 PRECISA DE AJUDA VISUAL?

Se mesmo seguindo este guia você não consegue verificar:

1. **Tente a ferramenta automatizada:**
   ```
   https://rdstopografia.com.br/teste-indexacao.html
   ```
   Ela faz tudo automaticamente!

2. **Use o Google:**
   ```
   https://search.google.com/search-console
   ```
   Inspeção de URL mostra exatamente o que o Google vê.

3. **Peça ajuda ao suporte do hosting:**
   Eles podem acessar o servidor e verificar diretamente.

---

**Última atualização:** 05/03/2026  
**Dificuldade:** ⭐⭐☆☆☆ (Fácil)  
**Tempo necessário:** 2-5 minutos  
**Ferramentas necessárias:** Apenas navegador
