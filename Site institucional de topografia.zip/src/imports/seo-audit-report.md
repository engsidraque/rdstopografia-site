Faça uma auditoria completa de SEO neste site institucional.

Analise se a página está otimizada para mecanismos de busca (Google) considerando os seguintes critérios:

1. Título da página (Title Tag)
- Verifique se contém palavras-chave relevantes.
- Sugira melhorias com foco em busca local.

2. Meta descrição
- Analise se existe e se está otimizada para cliques no Google.

3. Estrutura de headings
- Verifique se há H1, H2 e H3 corretamente organizados.

4. Palavras-chave
- Identifique as palavras-chave presentes na página.
- Sugira palavras-chave mais fortes para o nicho.

5. SEO local
- Analise se o site menciona cidade e região de atuação.
- Sugira melhorias para SEO local.

6. Conteúdo
- Avalie se o texto explica claramente os serviços.
- Sugira melhorias para aumentar relevância no Google.

7. Botões de conversão
- Verifique se existem chamadas para ação (CTA) claras.

8. Imagens
- Verifique se as imagens possuem ALT text descritivo.

9. Velocidade e estrutura
- Analise se o layout pode impactar negativamente o SEO.

10. Sugestões de melhoria
- Liste melhorias práticas para aumentar a chance do site aparecer no Google.

Contexto do site:
Empresa de topografia chamada RDS Topografia que atua em Guarulhos e região.

Serviços principais:
- Levantamento topográfico
- Locação de obra
- Georreferenciamento
- Regularização de imóveis

Objetivo do site:
Gerar leads e pedidos de orçamento para serviços de topografia.

No final gere:
1. Nota geral de SEO de 0 a 100
2. Lista de melhorias prioritárias
3. Versão otimizada do título e da descrição da página.