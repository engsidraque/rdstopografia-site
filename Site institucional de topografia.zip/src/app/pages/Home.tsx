import { lazy, Suspense } from 'react';
import { SEO } from '../components/SEO';
import { OrganizationSchema } from '../components/OrganizationSchema';
import { ResourcePreload } from '../components/ResourcePreload';
import { Hero } from '../components/Hero';
import { Authority } from '../components/Authority';
import { Services } from '../components/Services';

// Lazy load de componentes pesados (abaixo da dobra)
const Process = lazy(() => import('../components/Process').then(module => ({ default: module.Process })));
const ProjectsCarousel = lazy(() => import('../components/ProjectsCarousel').then(module => ({ default: module.ProjectsCarousel })));
const Testimonials = lazy(() => import('../components/Testimonials').then(module => ({ default: module.Testimonials })));
const CTAFinal = lazy(() => import('../components/CTAFinal').then(module => ({ default: module.CTAFinal })));

// Loading skeleton mínimo
const ComponentLoader = () => (
  <div style={{ minHeight: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <div style={{ color: '#9ca3af' }}>Carregando...</div>
  </div>
);

export default function Home() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "RDS Topografia",
    "image": "https://rdstopografia.com.br/og-image.jpg",
    "@id": "https://rdstopografia.com.br",
    "url": "https://rdstopografia.com.br",
    "telephone": "+55-11-94571-5195",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Guarulhos",
      "addressRegion": "SP",
      "addressCountry": "BR"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": -23.4538,
      "longitude": -46.5333
    },
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday"
      ],
      "opens": "08:00",
      "closes": "18:00"
    },
    "sameAs": [
      "https://www.facebook.com/rdstopografia",
      "https://www.instagram.com/rdstopografia"
    ],
    "priceRange": "$$",
    "areaServed": [
      {
        "@type": "City",
        "name": "Guarulhos"
      },
      {
        "@type": "City",
        "name": "São Paulo"
      },
      {
        "@type": "State",
        "name": "São Paulo"
      }
    ],
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "127"
    }
  };

  return (
    <>
      <ResourcePreload />
      <SEO
        title="Topografia em Guarulhos - Levantamento, Locação e Georreferenciamento"
        description="Topografia profissional em Guarulhos: levantamento topográfico, locação de obra, georreferenciamento INCRA. Engenheiro CREA ativo. Orçamento grátis!"
        canonical="/"
        keywords="topografia guarulhos, levantamento topográfico guarulhos, topógrafo guarulhos, locação de obra, georreferenciamento, memorial descritivo, planta topográfica, ART topografia, CREA, regularização imóveis guarulhos, empresa de topografia"
        schema={schema}
      />
      <OrganizationSchema />
      
      {/* Componentes críticos - renderização imediata */}
      <Hero />
      <Authority />
      <Services />
      
      {/* Componentes abaixo da dobra - lazy loading */}
      <Suspense fallback={<ComponentLoader />}>
        <Process />
      </Suspense>
      
      <Suspense fallback={<ComponentLoader />}>
        <ProjectsCarousel />
      </Suspense>
      
      <Suspense fallback={<ComponentLoader />}>
        <Testimonials />
      </Suspense>
      
      <Suspense fallback={<ComponentLoader />}>
        <CTAFinal />
      </Suspense>
    </>
  );
}
