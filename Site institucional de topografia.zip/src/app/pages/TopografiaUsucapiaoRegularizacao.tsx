import { SEO } from '../components/SEO';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Button } from '../components/ui/button';
import { Building2, CheckCircle2, Phone, MapPin, Ruler, Satellite } from 'lucide-react';
import { FAQSection } from '../components/FAQSection';
import { LeadQualification } from '../components/LeadQualification';
import { Link } from 'react-router-dom';

export default function TopografiaUsucapiaoRegularizacao() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "Topografia para Usucapião e Regularização",
    "provider": {
      "@type": "LocalBusiness",
      "name": "RDS Topografia",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Guarulhos",
        "addressRegion": "SP",
        "addressCountry": "BR"
      },
      "telephone": "+55-11-94571-5195"
    },
    "areaServed": [
      {
        "@type": "City",
        "name": "Guarulhos"
      },
      {
        "@type": "City",
        "name": "São Paulo"
      }
    ],
    "description": "Levantamento topográfico profissional para processos de usucapião e regularização de imóveis em Guarulhos com memorial descritivo e ART inclusa."
  };

  const breadcrumbItems = [
    { label: "Topografia para Usucapião e Regularização", path: "/topografia-usucapiao-regularizacao" }
  ];

  const benefits = [
    "Levantamento planialtimétrico georeferenciado",
    "Memorial descritivo com coordenadas",
    "Planta técnica para processo judicial",
    "ART específica para usucapião/regularização",
    "Atendimento a normas do CNJ e cartórios",
    "Experiência em processos extrajudiciais"
  ];

  const faqs = [
    {
      question: "O que é usucapião e quando posso requerer?",
      answer: "Usucapião é um direito previsto em lei que permite adquirir a propriedade de um imóvel após ocupá-lo de forma mansa, pacífica e ininterrupta por determinado período (varia de 5 a 15 anos dependendo do caso). É necessário comprovar a posse contínua e sem oposição do real proprietário."
    },
    {
      question: "Qual a importância do levantamento topográfico para usucapião?",
      answer: "O levantamento topográfico é fundamental e obrigatório para processos de usucapião. Ele delimita com precisão a área que está sendo reivindicada, fornece coordenadas georreferenciadas, memorial descritivo e planta técnica que serão anexados ao processo judicial ou extrajudicial."
    },
    {
      question: "Quanto custa um levantamento para usucapião?",
      answer: "O valor varia conforme o tamanho da área, localização, complexidade do terreno e tipo de levantamento necessário. Áreas rurais exigem georreferenciamento completo, enquanto áreas urbanas podem ter processos mais simples. Entre em contato para orçamento específico do seu caso."
    },
    {
      question: "Preciso de advogado além do topógrafo?",
      answer: "Sim. O topógrafo fornece a documentação técnica (planta e memorial descritivo), mas o processo de usucapião exige um advogado para conduzir a parte jurídica. Ambos são essenciais: o topógrafo documenta a área e o advogado formaliza o pedido judicial ou extrajudicial."
    },
    {
      question: "Quanto tempo demora o processo de usucapião?",
      answer: "O levantamento topográfico é concluído em poucos dias. Já o processo judicial de usucapião pode levar de 1 a 3 anos. A modalidade extrajudicial (feita em cartório) é mais rápida, podendo ser finalizada em 6 a 12 meses, desde que não haja contestação."
    }
  ];

  return (
    <>
      <SEO
        title="Topografia para Usucapião e Regularização em São Paulo - SP"
        description="Topografia para usucapião em SP. Engenheiro CREA, memorial descritivo georeferenciado, planta técnica e ART. Processos judiciais e extrajudiciais!"
        canonical="/topografia-usucapiao-regularizacao"
        keywords="topografia usucapião, levantamento para usucapião, regularização de imóvel, memorial descritivo usucapião, topografia regularização são paulo"
        schema={schema}
      />

      <div className="pt-20">
        {/* Breadcrumbs */}
        <Breadcrumbs items={breadcrumbItems} />
        
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-6">
                <Building2 className="h-8 w-8 text-red-500" />
                <span className="text-red-400">Serviço Especializado</span>
              </div>
              <h1 className="text-5xl md:text-6xl mb-6">
                Topografia para Usucapião e Regularização em São Paulo
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Levantamento topográfico especializado para processos de usucapião e regularização 
                fundiária com memorial descritivo, planta técnica e ART conforme exigências judiciais.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg"
                  onClick={() => window.open('https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento.', '_blank')}
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Consultar Especialista
                </Button>
                <Link to="/#servicos">
                  <Button size="lg" variant="outline" className="border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-6 text-lg">
                    Ver Todos os Serviços
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-4xl text-gray-900 mb-6">
                  Documentação Técnica Completa para Seu Processo
                </h2>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  Fornecemos toda a documentação topográfica necessária para processos de usucapião 
                  judicial e extrajudicial, além de regularização fundiária urbana e rural.
                </p>
                <div className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-700 text-lg">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1758574697284-8e84046a45ae?crop=entropy&cs=tinysrgb&fit=max&fm=webp&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXZpbCUyMGVuZ2luZWVyaW5nJTIwYmx1ZXByaW50JTIwcGxhbnN8ZW58MXx8fHwxNzcxNjgyMDMxfDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Planta técnica para usucapião"
                  className="rounded-2xl shadow-2xl"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Types of Services */}
        <section className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl text-gray-900 mb-6">
                Tipos de Regularização que Atendemos
              </h2>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <h3 className="text-2xl text-gray-900 mb-4">Usucapião Urbana</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Levantamento topográfico de imóveis urbanos com memorial descritivo e planta 
                  técnica para processos judiciais ou extrajudiciais (cartório).
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>• Usucapião ordinária</li>
                  <li>• Usucapião extraordinária</li>
                  <li>• Usucapião especial urbana</li>
                </ul>
              </div>

              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <h3 className="text-2xl text-gray-900 mb-4">Usucapião Rural</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Georreferenciamento de propriedades rurais conforme normas INCRA para processos 
                  de usucapião de áreas não registradas.
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>• Georreferenciamento INCRA</li>
                  <li>• Memorial descritivo técnico</li>
                  <li>• Planta georreferenciada</li>
                </ul>
              </div>

              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <h3 className="text-2xl text-gray-900 mb-4">Regularização Fundiária</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Levantamento para regularização de imóveis sem registro, loteamentos irregulares 
                  e processos de REURB (Regularização Fundiária Urbana).
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>• REURB-S e REURB-E</li>
                  <li>• Desmembramento</li>
                  <li>• Unificação de lotes</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Lead Qualification */}
        <LeadQualification />

        {/* Related Services */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl text-gray-900 mb-4">
                Outros Serviços de Topografia
              </h2>
              <p className="text-xl text-gray-600">
                Conheça nossos serviços especializados para cada necessidade
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <Link to="/levantamento-topografico" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <MapPin className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Levantamento Topográfico</h3>
                  <p className="text-gray-600 mb-4">Medição precisa do terreno com memorial descritivo e planta topográfica.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/locacao-de-obra" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Ruler className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Locação de Obra</h3>
                  <p className="text-gray-600 mb-4">Marcação precisa do projeto no terreno com equipamentos de alta tecnologia.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/georreferenciamento" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Satellite className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Georreferenciamento</h3>
                  <p className="text-gray-600 mb-4">Georreferenciamento de imóveis rurais conforme normas do INCRA.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <FAQSection faqs={faqs} />

        {/* CTA Final */}
        <section className="py-24 bg-red-600">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Regularize Sua Propriedade com Segurança Técnica
            </h2>
            <p className="text-xl text-red-100 mb-10 leading-relaxed">
              Nossa equipe possui experiência em processos de usucapião e regularização. 
              Entre em contato para análise do seu caso e orçamento técnico.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 94571-5195
                </Button>
              </a>
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 95860-5939
                </Button>
              </a>
              <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-red-600 px-12 py-6 text-lg">
                Consultar por WhatsApp
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}