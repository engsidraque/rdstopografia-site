import { SEO } from '../components/SEO';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Button } from '../components/ui/button';
import { Ruler, CheckCircle2, Phone, MapPin, Building2, Satellite } from 'lucide-react';
import { FAQSection } from '../components/FAQSection';
import { LeadQualification } from '../components/LeadQualification';
import { Link } from 'react-router-dom';

export default function LocacaoDeObra() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "Locação de Obra",
    "provider": {
      "@type": "LocalBusiness",
      "name": "RDS Topografia",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Guarulhos",
        "addressRegion": "SP",
        "addressCountry": "BR"
      },
      "telephone": "+55-11-94571-5195"
    },
    "areaServed": [
      {
        "@type": "City",
        "name": "Guarulhos"
      },
      {
        "@type": "City",
        "name": "São Paulo"
      }
    ],
    "description": "Serviço profissional de locação de obra em Guarulhos e região com engenheiro CREA, marcação precisa e ART inclusa."
  };

  const breadcrumbItems = [
    { label: "Locação de Obra", path: "/locacao-de-obra" }
  ];

  const benefits = [
    "Marcação precisa de eixos e pontos de referência",
    "Baseado em projeto aprovado pela prefeitura",
    "Equipamentos de alta precisão (estação total/GPS)",
    "Garantia de conformidade com o projeto",
    "ART de locação inclusa",
    "Acompanhamento técnico durante a marcação"
  ];

  const faqs = [
    {
      question: "O que é locação de obra e quando é necessária?",
      answer: "Locação de obra é a transferência do projeto arquitetônico aprovado para o terreno real, marcando com precisão onde cada elemento da construção deve ser executado. É necessária antes de iniciar qualquer construção para garantir que a obra seja executada conforme o projeto aprovado pela prefeitura."
    },
    {
      question: "Qual a diferença entre locação e levantamento topográfico?",
      answer: "O levantamento topográfico mede e documenta o terreno existente (é o primeiro passo). Já a locação de obra utiliza um projeto pronto e marca fisicamente no terreno onde serão construídos muros, fundações, pilares e demais elementos da edificação."
    },
    {
      question: "Quais documentos preciso ter para fazer a locação?",
      answer: "É necessário ter o projeto arquitetônico aprovado pela prefeitura (com plantas baixas, cortes e implantação) e, preferencialmente, o levantamento topográfico do terreno. O projeto deve estar em formato digital para maior precisão na execução."
    },
    {
      question: "Quanto tempo leva para fazer a locação de uma obra?",
      answer: "Uma locação residencial padrão normalmente é executada em 1 dia. Obras maiores ou mais complexas podem levar 2 a 3 dias. O prazo depende do tamanho da construção, quantidade de elementos a marcar e condições do terreno."
    },
    {
      question: "A locação evita problemas com a prefeitura?",
      answer: "Sim! A locação técnica garanta que sua obra está sendo executada exatamente conforme o projeto aprovado, evitando embargar por desconformidade. Além disso, a ART de locação é um documento que comprova a responsabilidade técnica do serviço."
    }
  ];

  return (
    <>
      <SEO
        title="Locação de Obra em Guarulhos - Marcação Topográfica de Terreno"
        description="Locação de obra em Guarulhos com engenheiro CREA. Marcação precisa de projetos, equipamentos de alta tecnologia e ART inclusa. Orçamento grátis!"
        canonical="/locacao-de-obra"
        keywords="locação de obra guarulhos, marcação de terreno, locação topográfica, topografia para construção, marcar obra guarulhos"
        schema={schema}
      />

      <div className="pt-20">
        {/* Breadcrumbs */}
        <Breadcrumbs items={breadcrumbItems} />
        
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-6">
                <Ruler className="h-8 w-8 text-red-500" />
                <span className="text-red-400">Serviço Especializado</span>
              </div>
              <h1 className="text-5xl md:text-6xl mb-6">
                Locação de Obra em Guarulhos e Região
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Marcação técnica profissional do seu projeto no terreno com equipamentos de precisão em Guarulhos. 
                Garanta que sua obra seja executada exatamente conforme o projeto aprovado pela prefeitura.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg"
                  onClick={() => window.open('https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento.', '_blank')}
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Solicitar Orçamento
                </Button>
                <Link to="/#servicos">
                  <Button size="lg" variant="outline" className="border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-6 text-lg">
                    Ver Todos os Serviços
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1687079661067-37edf116d6f3?crop=entropy&cs=tinysrgb&fit=max&fm=webp&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzaXRlJTIwYWVyaWFsJTIwZHJvbmUlMjB2aWV3fGVufDF8fHx8MTc3MTY4MjAzMXww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Locação de obra em execução"
                  className="rounded-2xl shadow-2xl"
                  loading="lazy"
                />
              </div>
              <div>
                <h2 className="text-4xl text-gray-900 mb-6">
                  Por Que Fazer Locação de Obra Profissional?
                </h2>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  A locação técnica garanta precisão na execução da obra, evita retrabalho e problemas 
                  com fiscalização. É o ponto de partida correto para qualquer construção.
                </p>
                <div className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-700 text-lg">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl text-gray-900 mb-6">
                Como Funciona o Serviço de Locação
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Processo técnico profissional em etapas claras
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-6">
                  01
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Análise do Projeto</h3>
                <p className="text-gray-600">Recebemos e analisamos o projeto aprovado pela prefeitura</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-6">
                  02
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Visita Técnica</h3>
                <p className="text-gray-600">Inspeção do terreno e planejamento da execução</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-6">
                  03
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Marcação no Terreno</h3>
                <p className="text-gray-600">Transferência precisa do projeto para o terreno real</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mx-auto mb-6">
                  04
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Entrega da ART</h3>
                <p className="text-gray-600">Documentação técnica com responsabilidade profissional</p>
              </div>
            </div>
          </div>
        </section>

        {/* Lead Qualification */}
        <LeadQualification />

        {/* Related Services */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl text-gray-900 mb-4">
                Outros Serviços de Topografia
              </h2>
              <p className="text-xl text-gray-600">
                Conheça nossos serviços especializados para cada necessidade
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <Link to="/levantamento-topografico" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <MapPin className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Levantamento Topográfico</h3>
                  <p className="text-gray-600 mb-4">Medição precisa do terreno com memorial descritivo e planta topográfica.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/topografia-usucapiao-regularizacao" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Building2 className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Usucapião e Regularização</h3>
                  <p className="text-gray-600 mb-4">Levantamento especializado para processos judiciais e extrajudiciais.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/georreferenciamento" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Satellite className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Georreferenciamento</h3>
                  <p className="text-gray-600 mb-4">Georreferenciamento de imóveis rurais conforme normas do INCRA.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <FAQSection faqs={faqs} />

        {/* CTA Final */}
        <section className="py-24 bg-red-600">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Pronto Para Iniciar Sua Obra Corretamente?
            </h2>
            <p className="text-xl text-red-100 mb-10 leading-relaxed">
              Faça a locação de obra com profissionais qualificados e evite problemas futuros. 
              Entre em contato para orçamento personalizado.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 94571-5195
                </Button>
              </a>
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 95860-5939
                </Button>
              </a>
              <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-red-600 px-12 py-6 text-lg">
                Solicitar por WhatsApp
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}