import { SEO } from '../components/SEO';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Button } from '../components/ui/button';
import { Satellite, CheckCircle2, Phone, MapPin, Ruler, Building2 } from 'lucide-react';
import { FAQSection } from '../components/FAQSection';
import { LeadQualification } from '../components/LeadQualification';
import { Link } from 'react-router-dom';

export default function Georreferenciamento() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "Georreferenciamento de Imóveis Rurais",
    "provider": {
      "@type": "LocalBusiness",
      "name": "RDS Topografia",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Guarulhos",
        "addressRegion": "SP",
        "addressCountry": "BR"
      },
      "telephone": "+55-11-94571-5195"
    },
    "areaServed": [
      {
        "@type": "State",
        "name": "São Paulo"
      },
      {
        "@type": "City",
        "name": "Guarulhos"
      }
    ],
    "description": "Serviço profissional de georreferenciamento de imóveis rurais em São Paulo com GPS geodésico, conforme normas INCRA e ART inclusa."
  };

  const breadcrumbItems = [
    { label: "Georreferenciamento", path: "/georreferenciamento" }
  ];

  const benefits = [
    "Levantamento com GPS geodésico de precisão",
    "Conformidade com norma INCRA (Lei 10.267/2001)",
    "Memorial descritivo georreferenciado",
    "Planta técnica com coordenadas UTM",
    "ART de georreferenciamento",
    "Suporte para certificação no INCRA"
  ];

  const faqs = [
    {
      question: "O que é georreferenciamento de imóveis rurais?",
      answer: "É o levantamento topográfico de propriedades rurais utilizando coordenadas geodésicas precisas (latitude, longitude e altitude), vinculando o imóvel ao Sistema Geodésico Brasileiro. É obrigatório por lei federal para registro de imóveis rurais em cartório."
    },
    {
      question: "Quais propriedades precisam de georreferenciamento?",
      answer: "Todas as propriedades rurais precisam ser georreferenciadas para desmembramento, remembramento ou registro no cartório, conforme Lei 10.267/2001. A obrigatoriedade foi implementada gradualmente, hoje abrangendo imóveis de todos os tamanhos."
    },
    {
      question: "Qual a diferença entre levantamento topográfico e georreferenciamento?",
      answer: "O levantamento topográfico tradicional utiliza coordenadas locais relativas. Já o georreferenciamento utiliza coordenadas absolutas vinculadas ao sistema geodésico oficial do Brasil (SIRGAS 2000), com maior precisão e aceito pelo INCRA para imóveis rurais."
    },
    {
      question: "Quanto tempo leva para georreferenciar uma propriedade?",
      answer: "O prazo varia conforme o tamanho da propriedade, condições de acesso e vegetação. Propriedades de até 50 hectares levam em média 15 a 30 dias entre levantamento de campo, processamento de dados e elaboração de memorial descritivo. Áreas maiores podem levar mais tempo."
    },
    {
      question: "Quanto custa o georreferenciamento?",
      answer: "O custo depende do tamanho da propriedade (hectares), localização, acesso, topografia do terreno e quantidade de confrontantes. Propriedades com muitas divisas ou terreno acidentado demandam mais tempo de trabalho. Entre em contato para orçamento específico."
    }
  ];

  return (
    <>
      <SEO
        title="Georreferenciamento de Imóveis Rurais - INCRA - São Paulo"
        description="Georreferenciamento INCRA em SP. Engenheiro credenciado, GPS geodésico, memorial descritivo georeferenciado e ART. Certificação INCRA. Orçamento grátis!"
        canonical="/georreferenciamento"
        keywords="georreferenciamento, georreferenciamento INCRA, topografia rural, georreferenciamento são paulo, certificação INCRA"
        schema={schema}
      />

      <div className="pt-20">
        {/* Breadcrumbs */}
        <Breadcrumbs items={breadcrumbItems} />
        
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-6">
                <Satellite className="h-8 w-8 text-red-500" />
                <span className="text-red-400">Serviço Especializado</span>
              </div>
              <h1 className="text-5xl md:text-6xl mb-6">
                Georreferenciamento de Imóveis Rurais - INCRA
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Georreferenciamento profissional de propriedades rurais com equipamentos de precisão 
                geodésica, conforme normas do INCRA. Atendemos toda região de São Paulo e interior.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg"
                  onClick={() => window.open('https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento.', '_blank')}
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Solicitar Orçamento
                </Button>
                <Link to="/#servicos">
                  <Button size="lg" variant="outline" className="border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-6 text-lg">
                    Ver Todos os Serviços
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1654643353084-10e62e05b9bf?crop=entropy&cs=tinysrgb&fit=max&fm=webp&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJ2ZXlvciUyMHRvcG9ncmFwaHklMjBlcXVpcG1lbnQlMjBmaWVsZCUyMHdvcmt8ZW58MXx8fHwxNzcxNjgyMDI5fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Georreferenciamento com GPS"
                  className="rounded-2xl shadow-2xl"
                  loading="lazy"
                />
              </div>
              <div>
                <h2 className="text-4xl text-gray-900 mb-6">
                  Georreferenciamento Certificado INCRA
                </h2>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  Realizamos todo o processo técnico necessário para certificação no INCRA, 
                  garantindo conformidade legal para registro do seu imóvel rural em cartório.
                </p>
                <div className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-700 text-lg">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl text-gray-900 mb-6">
                Processo de Georreferenciamento
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Etapas técnicas para certificação INCRA
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mb-6">
                  01
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Análise Documental</h3>
                <p className="text-gray-600">Verificação da documentação da propriedade e confrontantes</p>
              </div>

              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mb-6">
                  02
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Levantamento de Campo</h3>
                <p className="text-gray-600">Medição com GPS geodésico de todos os vértices da propriedade</p>
              </div>

              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mb-6">
                  03
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Processamento de Dados</h3>
                <p className="text-gray-600">Cálculo e ajuste das coordenadas conforme normas técnicas</p>
              </div>

              <div className="bg-white rounded-2xl p-8 border border-gray-200">
                <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center text-2xl mb-6">
                  04
                </div>
                <h3 className="text-xl text-gray-900 mb-3">Certificação INCRA</h3>
                <p className="text-gray-600">Entrega de memorial e suporte para protocolo no INCRA</p>
              </div>
            </div>
          </div>
        </section>

        {/* Legal Requirements */}
        <section className="py-24 bg-white">
          <div className="max-w-5xl mx-auto px-6 lg:px-8">
            <div className="bg-red-50 rounded-2xl p-12 border-2 border-red-100">
              <h2 className="text-3xl text-gray-900 mb-6">
                Obrigatoriedade Legal
              </h2>
              <p className="text-xl text-gray-700 leading-relaxed mb-6">
                A <strong>Lei Federal 10.267/2001</strong> tornou obrigatório o georreferenciamento de 
                imóveis rurais para qualquer ato de registro em cartório (compra, venda, desmembramento, etc).
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Sem o georreferenciamento certificado pelo INCRA, não é possível registrar alterações 
                da propriedade rural no Cartório de Registro de Imóveis. O prazo de adequação já expirou 
                e hoje todos os tamanhos de propriedades são obrigados a estar georreferenciados.
              </p>
            </div>
          </div>
        </section>

        {/* Lead Qualification */}
        <LeadQualification />

        {/* Related Services */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl text-gray-900 mb-4">
                Outros Serviços de Topografia
              </h2>
              <p className="text-xl text-gray-600">
                Conheça nossos serviços especializados para cada necessidade
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <Link to="/levantamento-topografico" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <MapPin className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Levantamento Topográfico</h3>
                  <p className="text-gray-600 mb-4">Medição precisa do terreno com memorial descritivo e planta topográfica.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/locacao-de-obra" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Ruler className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Locação de Obra</h3>
                  <p className="text-gray-600 mb-4">Marcação precisa do projeto no terreno com equipamentos de alta tecnologia.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/topografia-usucapiao-regularizacao" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Building2 className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Usucapião e Regularização</h3>
                  <p className="text-gray-600 mb-4">Levantamento especializado para processos judiciais e extrajudiciais.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <FAQSection faqs={faqs} />

        {/* CTA Final */}
        <section className="py-24 bg-red-600">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Regularize Sua Propriedade Rural Conforme a Lei
            </h2>
            <p className="text-xl text-red-100 mb-10 leading-relaxed">
              Entre em contato com nossa equipe especializada em georreferenciamento. 
              Fornecemos orçamento personalizado após análise técnica da propriedade.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 94571-5195
                </Button>
              </a>
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 95860-5939
                </Button>
              </a>
              <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-red-600 px-12 py-6 text-lg">
                Solicitar por WhatsApp
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}