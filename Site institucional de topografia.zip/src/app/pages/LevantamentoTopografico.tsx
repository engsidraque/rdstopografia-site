import { SEO } from '../components/SEO';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Button } from '../components/ui/button';
import { MapPin, CheckCircle2, Phone, Ruler, Building2, Satellite } from 'lucide-react';
import { FAQSection } from '../components/FAQSection';
import { LeadQualification } from '../components/LeadQualification';
import { Link } from 'react-router-dom';

export default function LevantamentoTopografico() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "serviceType": "Levantamento Topográfico Planialtimétrico",
    "provider": {
      "@type": "LocalBusiness",
      "name": "RDS Topografia",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Guarulhos",
        "addressRegion": "SP",
        "addressCountry": "BR"
      },
      "telephone": "+55-11-94571-5195"
    },
    "areaServed": [
      {
        "@type": "City",
        "name": "Guarulhos"
      },
      {
        "@type": "City",
        "name": "São Paulo"
      }
    ],
    "description": "Serviço profissional de levantamento topográfico planialtimétrico em Guarulhos e região com engenheiro CREA, memorial descritivo e ART inclusa."
  };

  const breadcrumbItems = [
    { label: "Levantamento Topográfico", path: "/levantamento-topografico" }
  ];

  const benefits = [
    "Medição precisa com equipamentos de alta tecnologia",
    "Memorial descritivo completo e detalhado",
    "Planta topográfica em formato digital (DWG/PDF)",
    "ART (Anotação de Responsabilidade Técnica) inclusa",
    "Atendimento em Guarulhos e região metropolitana",
    "Engenheiro responsável com CREA ativo"
  ];

  const faqs = [
    {
      question: "O que é levantamento topográfico planialtimétrico?",
      answer: "É um serviço técnico que mede e representa graficamente todas as características de um terreno, incluindo suas dimensões horizontais (planimetria) e variações de altitude (altimetria). É essencial para projetos de construção, regularização e planejamento urbano."
    },
    {
      question: "Qual o prazo para realizar o levantamento?",
      answer: "O prazo varia conforme o tamanho e complexidade do terreno. Normalmente, terrenos urbanos residenciais são concluídos entre 3 a 7 dias úteis, desde a visita técnica até a entrega da planta final com ART."
    },
    {
      question: "Como é calculado o preço do levantamento topográfico?",
      answer: "O preço depende de fatores como: tamanho do terreno (m²), localização, acesso, tipo de relevo, presença de vegetação densa e prazo de urgência. Cada projeto é único e requer uma avaliação técnica para orçamento preciso."
    },
    {
      question: "Preciso do levantamento topográfico para quê?",
      answer: "O levantamento topográfico é necessário para: aprovação de projetos arquitetônicos em prefeituras, planejamento de construções, regularização de imóveis, processos de usucapião, divisão de terrenos (desmembramento), estudos de viabilidade e documentação técnica."
    },
    {
      question: "O levantamento inclui a ART?",
      answer: "Sim! Todos os nossos levantamentos topográficos incluem a emissão da ART (Anotação de Responsabilidade Técnica) junto ao CREA-SP, garantindo a validade jurídica e técnica do documento para uso em prefeituras e cartórios."
    }
  ];

  return (
    <>
      <SEO
        title="Levantamento Topográfico Planialtimétrico em Guarulhos - SP"
        description="Levantamento topográfico em Guarulhos com engenheiro CREA. Medição precisa, planta topográfica, memorial descritivo e ART inclusa. Orçamento grátis!"
        canonical="/levantamento-topografico"
        keywords="levantamento topográfico, topografia guarulhos, planta topográfica, medição de terreno, levantamento planialtimétrico, topógrafo sp"
        schema={schema}
      />

      <div className="pt-20">
        {/* Breadcrumbs */}
        <Breadcrumbs items={breadcrumbItems} />
        
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-6">
                <MapPin className="h-8 w-8 text-red-500" />
                <span className="text-red-400">Serviço Especializado</span>
              </div>
              <h1 className="text-5xl md:text-6xl mb-6">
                Levantamento Topográfico Planialtimétrico em Guarulhos
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Medição técnica profissional com equipamentos de precisão, engenheiro responsável 
                CREA ativo e entrega de planta topográfica completa com ART para uso em prefeituras e projetos.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg"
                  onClick={() => window.open('https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento.', '_blank')}
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Solicitar Orçamento Agora
                </Button>
                <Link to="/">
                  <Button size="lg" variant="outline" className="border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-6 text-lg">
                    Ver Todos os Serviços
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-4xl text-gray-900 mb-6">
                  O Que Está Incluído no Serviço
                </h2>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  Nosso levantamento topográfico é completo e atende todas as exigências técnicas 
                  para aprovação em prefeituras e uso profissional.
                </p>
                <div className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
                      <p className="text-gray-700 text-lg">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1654643353084-10e62e05b9bf?crop=entropy&cs=tinysrgb&fit=max&fm=webp&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJ2ZXlvciUyMHRvcG9ncmFwaHklMjBlcXVpcG1lbnQlMjBmaWVsZCUyMHdvcmt8ZW58MXx8fHwxNzcxNjgyMDI5fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Levantamento topográfico em campo"
                  className="rounded-2xl shadow-2xl"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Info */}
        <section className="py-24 bg-gray-50">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-4xl text-gray-900 mb-6">
              Como é Calculado o Preço?
            </h2>
            <p className="text-xl text-gray-600 mb-12 leading-relaxed">
              O valor do levantamento topográfico depende de diversos fatores técnicos. 
              Cada projeto é único e requer análise específica para orçamento preciso.
            </p>
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="bg-white rounded-xl p-8 border border-gray-200">
                <h3 className="text-xl text-gray-900 mb-3">Tamanho do Terreno</h3>
                <p className="text-gray-600">Área em m² influencia diretamente no tempo e recursos necessários</p>
              </div>
              <div className="bg-white rounded-xl p-8 border border-gray-200">
                <h3 className="text-xl text-gray-900 mb-3">Localização e Acesso</h3>
                <p className="text-gray-600">Distância, acessibilidade e características da região</p>
              </div>
              <div className="bg-white rounded-xl p-8 border border-gray-200">
                <h3 className="text-xl text-gray-900 mb-3">Tipo de Relevo</h3>
                <p className="text-gray-600">Terrenos planos, inclinados ou com desnível acentuado</p>
              </div>
            </div>
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-12 py-6 text-lg">
              Solicitar Orçamento Personalizado
            </Button>
          </div>
        </section>

        {/* Lead Qualification */}
        <LeadQualification />

        {/* Related Services */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl text-gray-900 mb-4">
                Outros Serviços de Topografia
              </h2>
              <p className="text-xl text-gray-600">
                Conheça nossos serviços especializados para cada necessidade
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <Link to="/locacao-de-obra" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Ruler className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Locação de Obra</h3>
                  <p className="text-gray-600 mb-4">Marcação precisa do projeto no terreno com equipamentos de alta tecnologia.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/topografia-usucapiao-regularizacao" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Building2 className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Usucapião e Regularização</h3>
                  <p className="text-gray-600 mb-4">Levantamento especializado para processos judiciais e extrajudiciais.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
              <Link to="/georreferenciamento" className="group">
                <div className="bg-gray-50 rounded-xl p-8 border border-gray-200 hover:border-red-500 hover:shadow-xl transition-all">
                  <Satellite className="h-12 w-12 text-red-600 mb-4" />
                  <h3 className="text-2xl text-gray-900 mb-3 group-hover:text-red-600 transition-colors">Georreferenciamento</h3>
                  <p className="text-gray-600 mb-4">Georreferenciamento de imóveis rurais conforme normas do INCRA.</p>
                  <span className="text-red-600 font-medium group-hover:underline">Saiba mais →</span>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <FAQSection faqs={faqs} />

        {/* CTA Final */}
        <section className="py-24 bg-red-600">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Precisa de um Levantamento Topográfico Profissional?
            </h2>
            <p className="text-xl text-red-100 mb-10 leading-relaxed">
              Entre em contato agora e receba um orçamento personalizado. Nossa equipe técnica 
              está pronta para atender seu projeto com excelência e responsabilidade.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 94571-5195
                </Button>
              </a>
              <a href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg w-full sm:w-auto">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 95860-5939
                </Button>
              </a>
              <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-red-600 px-12 py-6 text-lg">
                Solicitar por WhatsApp
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}