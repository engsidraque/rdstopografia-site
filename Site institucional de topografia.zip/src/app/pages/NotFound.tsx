import { Link } from 'react-router-dom';
import { Home, Search, ArrowLeft } from 'lucide-react';
import { SEO } from '../components/SEO';

export default function NotFound() {
  return (
    <>
      <SEO 
        title="Página não encontrada - RDS Topografia"
        description="A página que você está procurando não existe. Retorne para a página inicial da RDS Topografia."
        canonicalUrl="https://rdstopografia.com.br/404"
        noindex={true}
      />

      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center px-6 py-32">
        <div className="max-w-2xl w-full text-center">
          {/* Ilustração 404 */}
          <div className="mb-8">
            <h1 className="text-[120px] md:text-[180px] font-bold text-gray-200 leading-none select-none">
              404
            </h1>
            <div className="flex justify-center -mt-16 md:-mt-24">
              <Search className="h-16 w-16 md:h-24 md:w-24 text-red-600 animate-pulse" />
            </div>
          </div>

          {/* Mensagem */}
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
            Página não encontrada
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-md mx-auto">
            Desculpe, a página que você está procurando não existe ou foi movida.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link
              to="/"
              className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg transition-colors font-semibold shadow-lg hover:shadow-xl"
            >
              <Home className="h-5 w-5" />
              Voltar para a Página Inicial
            </Link>
            
            <button
              onClick={() => window.history.back()}
              className="inline-flex items-center gap-2 bg-white hover:bg-gray-50 text-gray-700 border-2 border-gray-300 px-8 py-4 rounded-lg transition-colors font-semibold"
            >
              <ArrowLeft className="h-5 w-5" />
              Voltar à Página Anterior
            </button>
          </div>

          {/* Links rápidos */}
          <div className="mt-12 pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-500 mb-4">Você pode estar procurando por:</p>
            <div className="flex flex-wrap justify-center gap-3">
              <Link to="/levantamento-topografico" className="text-sm text-red-600 hover:text-red-700 hover:underline">
                Levantamento Topográfico
              </Link>
              <span className="text-gray-300">•</span>
              <Link to="/locacao-de-obra" className="text-sm text-red-600 hover:text-red-700 hover:underline">
                Locação de Obra
              </Link>
              <span className="text-gray-300">•</span>
              <Link to="/topografia-usucapiao-regularizacao" className="text-sm text-red-600 hover:text-red-700 hover:underline">
                Usucapião
              </Link>
              <span className="text-gray-300">•</span>
              <Link to="/georreferenciamento" className="text-sm text-red-600 hover:text-red-700 hover:underline">
                Georreferenciamento
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
