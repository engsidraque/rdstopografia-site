import { memo, useState, useEffect } from 'react';
import { Phone, Menu, X } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import logo from 'figma:asset/53b29bd27890412e2bfaf86a11ba15cea018c1e1.png';

export const Header = memo(function Header() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isActive = (path: string) => location.pathname === path;

  const closeMobileMenu = () => setMobileMenuOpen(false);

  // Fecha menu mobile com tecla Esc
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        closeMobileMenu();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [mobileMenuOpen]);

  // Fecha menu mobile ao navegar para outra página
  useEffect(() => {
    closeMobileMenu();
  }, [location.pathname]);

  // Previne scroll da página quando menu mobile está aberto
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const navLinks = [
    { path: '/', label: 'Início' },
    { path: '/levantamento-topografico', label: 'Levantamento' },
    { path: '/locacao-de-obra', label: 'Locação' },
    { path: '/topografia-usucapiao-regularizacao', label: 'Usucapião' },
    { path: '/georreferenciamento', label: 'Georreferenciamento' },
  ];

  return (
    <>
      {/* Skip to main content - Acessibilidade */}
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[100] focus:bg-red-600 focus:text-white focus:px-4 focus:py-2 focus:rounded-lg"
      >
        Pular para o conteúdo principal
      </a>

      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-28">
            {/* Logo - Otimizado para carregamento */}
            <Link to="/" className="flex-shrink-0" onClick={closeMobileMenu}>
              <img 
                src={logo} 
                alt="RDS Topografia - Serviços de Topografia em Guarulhos e São Paulo" 
                className="h-20 md:h-24 w-auto"
                width="200"
                height="96"
                loading="eager"
                fetchpriority="high"
                decoding="async"
              />
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6" aria-label="Navegação principal">
              {navLinks.map(({ path, label }) => (
                <Link 
                  key={path}
                  to={path} 
                  className={`transition-colors font-medium ${
                    isActive(path) 
                      ? 'text-red-600' 
                      : 'text-gray-700 hover:text-red-600'
                  }`}
                  aria-current={isActive(path) ? 'page' : undefined}
                >
                  {label}
                </Link>
              ))}
              <a 
                href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-colors font-medium"
                aria-label="Solicitar orçamento via WhatsApp"
              >
                Orçamento
              </a>
            </nav>

            {/* Contact Info - Desktop */}
            <div className="hidden lg:flex items-center gap-6">
              <a 
                href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-center gap-2 text-gray-700 hover:text-red-600 transition-colors"
                aria-label="Ligar para (11) 94571-5195"
              >
                <Phone className="h-4 w-4" aria-hidden="true" />
                <span>(11) 94571-5195</span>
              </a>
              <a 
                href="https://wa.me/5511958605939?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-center gap-2 text-gray-700 hover:text-red-600 transition-colors"
                aria-label="Ligar para (11) 95860-5939"
              >
                <Phone className="h-4 w-4" aria-hidden="true" />
                <span>(11) 95860-5939</span>
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-700 hover:text-red-600 transition-colors"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
              aria-expanded={mobileMenuOpen}
              aria-controls="mobile-menu"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div 
            id="mobile-menu"
            className="md:hidden border-t border-gray-200 bg-white"
            role="navigation"
            aria-label="Menu de navegação mobile"
          >
            <div className="px-6 py-4 space-y-3">
              {navLinks.map(({ path, label }) => (
                <Link
                  key={path}
                  to={path}
                  onClick={closeMobileMenu}
                  className={`block py-2 px-4 rounded-lg transition-colors ${
                    isActive(path)
                      ? 'bg-red-50 text-red-600 font-semibold'
                      : 'text-gray-700 hover:bg-gray-50 hover:text-red-600'
                  }`}
                  aria-current={isActive(path) ? 'page' : undefined}
                >
                  {label}
                </Link>
              ))}
              
              {/* Mobile Contact */}
              <div className="pt-4 space-y-2 border-t border-gray-200">
                <a 
                  href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center gap-2 py-2 px-4 text-gray-700 hover:bg-gray-50 hover:text-red-600 rounded-lg transition-colors"
                  onClick={closeMobileMenu}
                >
                  <Phone className="h-4 w-4" aria-hidden="true" />
                  <span>(11) 94571-5195</span>
                </a>
                <a 
                  href="https://wa.me/5511958605939?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center gap-2 py-2 px-4 text-gray-700 hover:bg-gray-50 hover:text-red-600 rounded-lg transition-colors"
                  onClick={closeMobileMenu}
                >
                  <Phone className="h-4 w-4" aria-hidden="true" />
                  <span>(11) 95860-5939</span>
                </a>
              </div>

              {/* Mobile CTA */}
              <a 
                href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                target="_blank" 
                rel="noopener noreferrer" 
                className="block w-full bg-red-600 hover:bg-red-700 text-white text-center px-6 py-3 rounded-lg transition-colors font-semibold mt-4"
                onClick={closeMobileMenu}
              >
                Solicitar Orçamento
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
});
