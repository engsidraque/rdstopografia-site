import { memo } from 'react';
import { MapPin, Ruler, Building2, Satellite, BarChart3, Plane, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Services = memo(function Services() {
  const services = [
    {
      icon: MapPin,
      title: "Levantamento Topográfico Planialtimétrico",
      description: "Medição precisa de terrenos com coordenadas planimétricas e altimétricas, essencial para projetos de engenharia e arquitetura.",
      slug: "/levantamento-topografico"
    },
    {
      icon: Ruler,
      title: "Locação de Obras",
      description: "Marcação exata de pontos de referência no terreno conforme projeto aprovado, garantindo execução precisa da obra.",
      slug: "/locacao-de-obra"
    },
    {
      icon: Building2,
      title: "Regularização e Usucapião",
      description: "Levantamentos técnicos para processos de regularização fundiária e usucapião com memorial descritivo completo.",
      slug: "/topografia-usucapiao-regularizacao"
    },
    {
      icon: Satellite,
      title: "Georreferenciamento",
      description: "Georreferenciamento de imóveis rurais conforme normas do INCRA com precisão geodésica certificada.",
      slug: "/georreferenciamento"
    },
    {
      icon: BarChart3,
      title: "Estudos para Pavimentação",
      description: "Levantamentos topográficos detalhados para projetos de pavimentação e infraestrutura viária.",
      slug: "/levantamento-topografico"
    },
    {
      icon: Plane,
      title: "Levantamento com Drone",
      description: "Mapeamento aéreo com tecnologia de ponta para grandes áreas, com ortomosaicos e modelos 3D.",
      slug: "/levantamento-topografico"
    }
  ];

  return (
    <section id="servicos" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-6">
            Serviços Especializados de Topografia em Guarulhos
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Oferecemos soluções completas em topografia para Guarulhos e região com tecnologia de ponta, 
            profissionais qualificados e memorial descritivo completo para atender todas as suas necessidades técnicas.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Link
              key={index}
              to={service.slug}
              className="group bg-white rounded-2xl p-8 border border-gray-200 hover:border-red-600 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-14 h-14 bg-red-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-red-600 transition-colors">
                <service.icon className="h-7 w-7 text-red-600 group-hover:text-white transition-colors" />
              </div>
              
              <h3 className="text-xl text-gray-900 mb-3">
                {service.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed mb-6">
                {service.description}
              </p>
              
              <div className="flex items-center text-red-600 group-hover:text-red-700">
                Saiba Mais
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
});
