import { memo } from 'react';
import { MessageCircle } from 'lucide-react';

export const WhatsAppButton = memo(function WhatsAppButton() {
  const phoneNumber = '5511945715195'; // Formato internacional sem +
  const message = encodeURIComponent('Olá! Vi a RDS Topografia no site e gostaria de solicitar um orçamento.');
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-2xl transition-all duration-300 hover:scale-110 group focus:outline-none focus:ring-4 focus:ring-green-300"
      aria-label="Solicitar orçamento via WhatsApp - Abre em nova janela"
      title="Fale conosco no WhatsApp"
    >
      <MessageCircle className="h-7 w-7" aria-hidden="true" />
      <span 
        className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 group-focus:opacity-100 transition-opacity pointer-events-none"
        aria-hidden="true"
      >
        Fale conosco no WhatsApp
      </span>
    </a>
  );
});
