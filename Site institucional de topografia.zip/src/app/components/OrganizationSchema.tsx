import { Helmet } from 'react-helmet-async';

export function OrganizationSchema() {
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "RDS Topografia",
    "alternateName": "RDS Topografia Guarulhos",
    "url": "https://rdstopografia.com.br",
    "logo": "https://rdstopografia.com.br/logo.png",
    "description": "Empresa de topografia especializada em levantamento topográfico, locação de obra, georreferenciamento e regularização de imóveis em Guarulhos e região metropolitana de São Paulo.",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Guarulhos",
      "addressRegion": "SP",
      "postalCode": "07000-000",
      "addressCountry": "BR"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": -23.4538,
      "longitude": -46.5333
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+55-11-94571-5195",
      "contactType": "customer service",
      "availableLanguage": ["Portuguese"],
      "areaServed": "BR"
    },
    "sameAs": [
      "https://www.facebook.com/rdstopografia",
      "https://www.instagram.com/rdstopografia"
    ],
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "127"
    },
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday"
      ],
      "opens": "08:00",
      "closes": "18:00"
    },
    "priceRange": "$$",
    "areaServed": [
      {
        "@type": "City",
        "name": "Guarulhos"
      },
      {
        "@type": "City",
        "name": "São Paulo"
      },
      {
        "@type": "State",
        "name": "São Paulo"
      }
    ]
  };

  return (
    <Helmet>
      <script type="application/ld+json">
        {JSON.stringify(organizationSchema)}
      </script>
    </Helmet>
  );
}
