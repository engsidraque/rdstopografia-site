import { memo } from 'react';
import { Helmet } from 'react-helmet-async';
import heroImage from 'figma:asset/fbade2f89e7230f1bc5f5558c3766e9db13f92f5.png';
import logo from 'figma:asset/53b29bd27890412e2bfaf86a11ba15cea018c1e1.png';

/**
 * Componente para preload de recursos críticos
 * Melhora FCP e LCP ao carregar recursos importantes antecipadamente
 */
export const ResourcePreload = memo(function ResourcePreload() {
  return (
    <Helmet>
      {/* Preload de imagens críticas para LCP */}
      <link rel="preload" as="image" href={heroImage} fetchpriority="high" />
      <link rel="preload" as="image" href={logo} fetchpriority="high" />
      
      {/* DNS Prefetch para recursos externos */}
      <link rel="dns-prefetch" href="https://images.unsplash.com" />
      <link rel="dns-prefetch" href="https://wa.me" />
      
      {/* Preconnect para melhorar latência de conexão */}
      <link rel="preconnect" href="https://images.unsplash.com" crossOrigin="anonymous" />
    </Helmet>
  );
});
