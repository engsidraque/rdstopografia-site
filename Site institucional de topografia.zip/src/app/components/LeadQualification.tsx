import { MapPin, Home, Maximize, Target, Clock, AlertCircle } from 'lucide-react';

export function LeadQualification() {
  const requirements = [
    {
      icon: MapPin,
      text: "Endereço completo ou bairro"
    },
    {
      icon: Home,
      text: "Tipo do imóvel (residencial, comercial, rural)"
    },
    {
      icon: Maximize,
      text: "Metragem aproximada do terreno"
    },
    {
      icon: Target,
      text: "Objetivo (obra, usucapião, regularização, etc.)"
    },
    {
      icon: Clock,
      text: "Prazo desejado para execução"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <div className="bg-white rounded-2xl p-8 md:p-12 border-2 border-red-100">
          <div className="flex items-start gap-4 mb-8">
            <div className="flex-shrink-0">
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
            <div>
              <h3 className="text-2xl text-gray-900 mb-2">
                Para Solicitar um Orçamento Preciso
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Por favor, tenha em mãos as seguintes informações. Isso nos permite oferecer 
                um orçamento mais preciso e reduz o tempo de resposta.
              </p>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-6 mb-8">
            {requirements.map((req, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="flex-shrink-0 w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <req.icon className="h-5 w-5 text-red-600" />
                </div>
                <p className="text-gray-700">{req.text}</p>
              </div>
            ))}
          </div>

          <div className="bg-red-50 rounded-xl p-6 border border-red-100">
            <p className="text-gray-700 leading-relaxed">
              <span className="text-red-600">Importante:</span> Atendemos apenas solicitações com 
              real intenção de contratação. Nosso time técnico está disponível para esclarecer 
              dúvidas e oferecer consultoria especializada.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
