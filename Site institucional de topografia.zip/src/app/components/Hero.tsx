import { memo } from 'react';
import { PhoneCall } from 'lucide-react';
import { Button } from './ui/button';
import heroImage from 'figma:asset/fbade2f89e7230f1bc5f5558c3766e9db13f92f5.png';

export const Hero = memo(function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-20">
      {/* Background Image with Overlay - Otimizado para LCP */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Equipamento topográfico em campo Guarulhos - Estação total da RDS Topografia para levantamento planialtimétrico"
          className="w-full h-full object-cover"
          loading="eager"
          fetchpriority="high"
          width="1920"
          height="1080"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-24">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-6xl lg:text-7xl text-white mb-6 tracking-tight">
            Topografia de Precisão em Guarulhos e Região Metropolitana
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-12 leading-relaxed">
            Levantamentos topográficos, locação de obra, georreferenciamento e regularização de imóveis com engenheiro CREA responsável em Guarulhos e toda região metropolitana de São Paulo.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              size="lg"
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-6 text-lg font-semibold"
              onClick={() => window.open('https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento.', '_blank')}
            >
              Solicitar Orçamento
            </Button>
            <a 
              href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-6 py-4 text-lg font-semibold bg-white/10 backdrop-blur-sm border-2 border-white/80 text-white hover:bg-white hover:text-gray-900 transition-all duration-300 rounded-lg shadow-lg hover:shadow-xl whitespace-nowrap"
            >
              <PhoneCall className="h-5 w-5 flex-shrink-0" />
              <span>(11) 94571-5195</span>
            </a>
            <a 
              href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-6 py-4 text-lg font-semibold bg-white/10 backdrop-blur-sm border-2 border-white/80 text-white hover:bg-white hover:text-gray-900 transition-all duration-300 rounded-lg shadow-lg hover:shadow-xl whitespace-nowrap"
            >
              <PhoneCall className="h-5 w-5 flex-shrink-0" />
              <span>(11) 95860-5939</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
});
