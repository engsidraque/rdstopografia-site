import { memo } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import img1 from 'figma:asset/fa2deb5f4293850b642a2c80f0ac86345df3df58.png';
import img2 from 'figma:asset/f1c0ced8f8d0916c03a5fbedcb812665360eff09.png';
import img3 from 'figma:asset/0d08cb00283074c8408c3466fcf4d227892490cd.png';
import img4 from 'figma:asset/d65045dbe8c6f3e7a2181a895e843c52e195c608.png';
import img5 from 'figma:asset/8fdd95a39811127ade3d9e16387853e3b78319b0.png';
import img6 from 'figma:asset/fbade2f89e7230f1bc5f5558c3766e9db13f92f5.png';
import img7 from 'figma:asset/57bbc9791b3fb72ec5ce1708695ce98a8c2eeea7.png';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface ArrowProps {
  onClick?: () => void;
}

const NextArrow = memo(function NextArrow({ onClick }: ArrowProps) {
  return (
    <button
      onClick={onClick}
      className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-red-600 hover:bg-red-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
      aria-label="Próximo"
    >
      <ChevronRight className="h-6 w-6" />
    </button>
  );
});

const PrevArrow = memo(function PrevArrow({ onClick }: ArrowProps) {
  return (
    <button
      onClick={onClick}
      className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-red-600 hover:bg-red-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
      aria-label="Anterior"
    >
      <ChevronLeft className="h-6 w-6" />
    </button>
  );
});

export const ProjectsCarousel = memo(function ProjectsCarousel() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    pauseOnHover: true,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    customPaging: () => (
      <div className="w-3 h-3 bg-gray-400 rounded-full hover:bg-red-600 transition-colors duration-300" />
    ),
    dotsClass: "slick-dots !bottom-6",
    lazyLoad: 'progressive' as const,
  };

  const images = [
    { src: img1, alt: 'Equipamento topográfico em área industrial' },
    { src: img2, alt: 'Profissional RDS Topografia em campo' },
    { src: img3, alt: 'Levantamento em canteiro de obras' },
    { src: img4, alt: 'Topografia em obra de grande porte' },
    { src: img5, alt: 'Locação em estrada rural' },
    { src: img6, alt: 'Serviço topográfico em rodovia' },
    { src: img7, alt: 'Levantamento em via pública' },
  ];

  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl mb-6 text-gray-900">
            Nossos Trabalhos em Campo
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Atuando em projetos de infraestrutura, obras comerciais, industriais e regularização de imóveis
          </p>
        </div>

        {/* Carousel */}
        <div className="relative carousel-wrapper">
          <Slider {...settings}>
            {images.map((image, index) => (
              <div key={index} className="outline-none">
                <div className="px-2">
                  <div className="relative h-[500px] md:h-[600px] rounded-2xl overflow-hidden shadow-2xl">
                    <img
                      src={image.src}
                      alt={image.alt}
                      className="w-full h-full object-cover"
                      loading="lazy"
                      decoding="async"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  </div>
                </div>
              </div>
            ))}
          </Slider>
        </div>
      </div>

      <style>{`
        .carousel-wrapper .slick-dots li button:before {
          display: none;
        }
        
        .carousel-wrapper .slick-dots li {
          margin: 0 6px;
        }
        
        .carousel-wrapper .slick-dots li div {
          transition: all 0.3s ease;
        }
        
        .carousel-wrapper .slick-dots li.slick-active div {
          background-color: #dc2626;
          width: 2rem;
          border-radius: 9999px;
        }
        
        .carousel-wrapper .slick-slide {
          padding: 0 8px;
        }
        
        .carousel-wrapper .slick-list {
          margin: 0 -8px;
        }
      `}</style>
    </section>
  );
});
