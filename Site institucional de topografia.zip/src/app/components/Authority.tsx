import { memo } from 'react';
import { Award, Shield, Users, HeadphonesIcon } from 'lucide-react';

export const Authority = memo(function Authority() {
  const credentials = [
    {
      icon: Award,
      title: "CREA Ativo",
      description: "Registro ativo no Conselho Regional de Engenharia e Agronomia"
    },
    {
      icon: Shield,
      title: "Responsabilidade Técnica",
      description: "Todos os projetos com ART (Anotação de Responsabilidade Técnica)"
    },
    {
      icon: Users,
      title: "Experiência Comprovada",
      description: "Mais de 500 projetos executados com excelência técnica"
    },
    {
      icon: HeadphonesIcon,
      title: "Atendimento Personalizado",
      description: "Suporte técnico direto com o engenheiro responsável"
    }
  ];

  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image */}
          <div className="relative">
            <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1766830110938-0ea8a6d78ecb?crop=entropy&cs=tinysrgb&fit=max&fm=webp&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b3RhbCUyMHN0YXRpb24lMjBzdXJ2ZXlpbmclMjBlcXVpcG1lbnQlMjBmaWVsZHxlbnwxfHx8fDE3NzIzNzQwNTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Estação total topográfica Guarulhos - Equipamento de precisão RDS Topografia para levantamento planialtimétrico"
                className="w-full h-full object-cover"
                loading="lazy"
                width="1080"
                height="1350"
                decoding="async"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-red-600 text-white p-8 rounded-xl shadow-xl">
              <p className="text-5xl mb-1">500+</p>
              <p className="text-sm opacity-90">Projetos Realizados</p>
            </div>
          </div>

          {/* Content */}
          <div>
            <h2 className="text-4xl md:text-5xl text-gray-900 mb-6">
              Autoridade e Credibilidade Técnica
            </h2>
            <p className="text-xl text-gray-600 mb-12 leading-relaxed">
              Empresa de topografia em Guarulhos com profissionais qualificados e registro ativo no CREA, 
              garantindo a validade jurídica e técnica de todos os nossos serviços em Guarulhos e região metropolitana.
            </p>

            <div className="grid sm:grid-cols-2 gap-8">
              {credentials.map((item, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                      <item.icon className="h-6 w-6 text-red-600" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-gray-900 mb-2">{item.title}</h3>
                    <p className="text-sm text-gray-600 leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});
