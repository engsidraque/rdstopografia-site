import { memo } from 'react';
import { Star, Quote } from 'lucide-react';
import img1 from 'figma:asset/fa2deb5f4293850b642a2c80f0ac86345df3df58.png';
import img2 from 'figma:asset/f1c0ced8f8d0916c03a5fbedcb812665360eff09.png';
import img3 from 'figma:asset/8fdd95a39811127ade3d9e16387853e3b78319b0.png';
import img4 from 'figma:asset/d65045dbe8c6f3e7a2181a895e843c52e195c608.png';

export const Testimonials = memo(function Testimonials() {
  const testimonials = [
    {
      name: "Carlos Eduardo Silva",
      role: "Engenheiro Civil",
      company: "Construtora Alicerce",
      text: "Precisão impecável nos levantamentos. A equipe da RDS entregou todas as plantas dentro do prazo e com a documentação completa. Recomendo para qualquer projeto que exija responsabilidade técnica.",
      rating: 5
    },
    {
      name: "Marina Oliveira",
      role: "Arquiteta",
      company: "Espaço Arquitetura",
      text: "Excelente atendimento técnico! O engenheiro responsável esclareceu todas as dúvidas e acompanhou pessoalmente o levantamento. A ART foi emitida rapidamente e sem complicações.",
      rating: 5
    },
    {
      name: "Roberto Mendes",
      role: "Proprietário Rural",
      company: "Fazenda Santa Helena",
      text: "Contratei para georreferenciamento da propriedade rural. Trabalho sério, profissional e conforme exigências do INCRA. Todo processo foi transparente e bem documentado.",
      rating: 5
    }
  ];

  const stats = [
    { value: "500+", label: "Projetos Realizados" },
    { value: "350+", label: "Clientes Atendidos" },
    { value: "98%", label: "Taxa de Satisfação" }
  ];

  return (
    <section id="depoimentos" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <p className="text-5xl md:text-6xl text-red-600 mb-2">{stat.value}</p>
              <p className="text-gray-600">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-6">
            O Que Nossos Clientes Dizem
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Depoimentos reais de profissionais e empresas que confiaram em nossos serviços técnicos.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-2xl p-8 relative"
            >
              {/* Quote Icon */}
              <div className="absolute top-8 right-8 opacity-10">
                <Quote className="h-16 w-16 text-red-600" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-red-600 text-red-600" />
                ))}
              </div>

              {/* Testimonial Text */}
              <p className="text-gray-700 leading-relaxed mb-8">
                "{testimonial.text}"
              </p>

              {/* Author */}
              <div className="border-t border-gray-200 pt-6">
                <p className="text-gray-900 mb-1">{testimonial.name}</p>
                <p className="text-sm text-gray-500">{testimonial.role}</p>
                <p className="text-sm text-red-600">{testimonial.company}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Project Gallery */}
        <div className="mt-20">
          <h3 className="text-3xl text-gray-900 mb-8 text-center">
            Projetos Executados
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="aspect-square rounded-xl overflow-hidden">
              <img
                src={img1}
                alt="Equipamento topográfico em área de terraplenagem"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                loading="lazy"
                decoding="async"
              />
            </div>
            <div className="aspect-square rounded-xl overflow-hidden">
              <img
                src={img2}
                alt="Profissional RDS realizando levantamento em campo"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                loading="lazy"
                decoding="async"
              />
            </div>
            <div className="aspect-square rounded-xl overflow-hidden">
              <img
                src={img3}
                alt="Levantamento em canteiro de obras com armação"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                loading="lazy"
                decoding="async"
              />
            </div>
            <div className="aspect-square rounded-xl overflow-hidden">
              <img
                src={img4}
                alt="Marco geodésico em área costeira"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                loading="lazy"
                decoding="async"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});
