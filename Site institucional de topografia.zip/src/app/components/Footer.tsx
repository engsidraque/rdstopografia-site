import { memo } from 'react';
import { MapPin, Phone, Mail, Facebook, Instagram, Linkedin } from 'lucide-react';
import logo from 'figma:asset/53b29bd27890412e2bfaf86a11ba15cea018c1e1.png';
import { Link } from 'react-router-dom';

export const Footer = memo(function Footer() {
  return (
    <footer id="contato" className="bg-gray-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid md:grid-cols-5 gap-12 mb-12">
          {/* Company Info */}
          <div className="md:col-span-2">
            <Link to="/" className="inline-block mb-4">
              <img 
                src={logo} 
                alt="RDS Topografia" 
                className="h-20 w-auto brightness-0 invert" 
                width="200"
                height="80"
                loading="lazy"
                decoding="async"
              />
            </Link>
            <p className="text-gray-400 leading-relaxed mb-6">
              Empresa especializada em serviços de topografia com responsabilidade técnica. 
              Profissionais qualificados e registro ativo no CREA.
            </p>
            <div className="space-y-3">
              <p className="text-gray-400">
                <span className="text-red-400">CNPJ:</span> 51.191.564/0001-90
              </p>
              <p className="text-red-400">
                CREA/SP
              </p>
              <p className="text-gray-400">
                Engenheiro Responsável: Sidraque Morais
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg mb-4">Serviços</h4>
            <div className="space-y-3">
              <Link to="/levantamento-topografico" className="block text-gray-400 hover:text-red-400 transition-colors">
                Levantamento Topográfico
              </Link>
              <Link to="/locacao-de-obra" className="block text-gray-400 hover:text-red-400 transition-colors">
                Locação de Obra
              </Link>
              <Link to="/topografia-usucapiao-regularizacao" className="block text-gray-400 hover:text-red-400 transition-colors">
                Usucapião e Regularização
              </Link>
              <Link to="/georreferenciamento" className="block text-gray-400 hover:text-red-400 transition-colors">
                Georreferenciamento
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg mb-4 font-semibold">Contato</h4>
            <div className="space-y-3">
              <a 
                href="https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-start gap-3 text-gray-400 hover:text-red-400 transition-colors"
                aria-label="Contatar via WhatsApp: (11) 94571-5195"
              >
                <Phone className="h-5 w-5 mt-0.5 flex-shrink-0" aria-hidden="true" />
                <span>(11) 94571-5195</span>
              </a>
              <a 
                href="https://wa.me/5511958605939?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento." 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-start gap-3 text-gray-400 hover:text-red-400 transition-colors"
                aria-label="Contatar via WhatsApp: (11) 95860-5939"
              >
                <Phone className="h-5 w-5 mt-0.5 flex-shrink-0" aria-hidden="true" />
                <span>(11) 95860-5939</span>
              </a>
              <a 
                href="mailto:contato@rdstopografia.com.br" 
                className="flex items-start gap-3 text-gray-400 hover:text-red-400 transition-colors"
                aria-label="Enviar e-mail para contato@rdstopografia.com.br"
              >
                <Mail className="h-5 w-5 mt-0.5 flex-shrink-0" aria-hidden="true" />
                <span>contato@rdstopografia.com.br</span>
              </a>
              <div className="flex items-start gap-3 text-gray-400">
                <MapPin className="h-5 w-5 mt-0.5 flex-shrink-0" aria-hidden="true" />
                <span>Atendemos toda a região da Grande São Paulo e interior</span>
              </div>
            </div>
          </div>

          {/* Social Media & Links */}
          <div>
            <h4 className="text-lg mb-4 font-semibold">Siga-nos</h4>
            <div className="flex gap-4" role="list" aria-label="Redes sociais">
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-red-600 transition-colors focus:outline-none focus:ring-2 focus:ring-red-400"
                aria-label="Seguir no Facebook - Link em breve"
                role="listitem"
              >
                <Facebook className="h-5 w-5" aria-hidden="true" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-red-600 transition-colors focus:outline-none focus:ring-2 focus:ring-red-400"
                aria-label="Seguir no Instagram - Link em breve"
                role="listitem"
              >
                <Instagram className="h-5 w-5" aria-hidden="true" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-red-600 transition-colors focus:outline-none focus:ring-2 focus:ring-red-400"
                aria-label="Seguir no LinkedIn - Link em breve"
                role="listitem"
              >
                <Linkedin className="h-5 w-5" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
          <p>© 2026 RDS Topografia. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
});
