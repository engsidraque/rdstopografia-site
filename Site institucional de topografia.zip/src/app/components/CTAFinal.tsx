import { memo } from 'react';
import { Button } from './ui/button';

export const CTAFinal = memo(function CTAFinal() {
  return (
    <section className="py-24 bg-red-600">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl text-white mb-6">
          Precisa de Topografia em Guarulhos com Responsabilidade Técnica?
        </h2>
        <p className="text-xl text-red-100 mb-10 leading-relaxed">
          Entre em contato agora e receba um orçamento personalizado para levantamento topográfico, 
          locação de obra ou georreferenciamento em Guarulhos. Nossa equipe está pronta para atendê-lo com a excelência técnica que você precisa.
        </p>
        
        <Button
          size="lg"
          className="bg-white text-red-600 hover:bg-gray-100 px-12 py-6 text-lg mb-6"
          onClick={() => window.open('https://wa.me/5511945715195?text=Ol%C3%A1!%20Vi%20a%20RDS%20Topografia%20no%20site%20e%20gostaria%20de%20solicitar%20um%20or%C3%A7amento.', '_blank')}
        >
          Solicitar Orçamento Agora
        </Button>
        
        <p className="text-sm text-red-100 opacity-90">
          Atendemos apenas solicitações com real intenção de contratação.
        </p>
      </div>
    </section>
  );
});
