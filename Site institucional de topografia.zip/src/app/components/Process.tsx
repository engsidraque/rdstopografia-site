import { memo } from 'react';
import { Search, MapPinned, Cog, FileCheck } from 'lucide-react';

export const Process = memo(function Process() {
  const steps = [
    {
      number: "01",
      icon: Search,
      title: "Análise Técnica Inicial",
      description: "Avaliamos suas necessidades e definimos o escopo técnico do projeto com base nas normas vigentes."
    },
    {
      number: "02",
      icon: MapPinned,
      title: "Visita ao Local",
      description: "Nossa equipe realiza visita técnica para reconhecimento do terreno e planejamento dos trabalhos."
    },
    {
      number: "03",
      icon: Cog,
      title: "Execução do Levantamento",
      description: "Utilizamos equipamentos de alta precisão para coleta de dados topográficos conforme metodologia técnica."
    },
    {
      number: "04",
      icon: FileCheck,
      title: "Entrega de Planta e ART",
      description: "Fornecemos planta técnica completa, memorial descritivo e ART (Anotação de Responsabilidade Técnica)."
    }
  ];

  return (
    <section id="processo" className="py-24 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl mb-6">
            Processo de Trabalho Profissional
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-4">
            Seguimos um processo técnico rigoroso para garantir precisão e conformidade em todos os nossos serviços.
          </p>
          <p className="text-red-400 text-lg">
            Trabalhamos apenas com serviços técnicos contratados formalmente.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-20 left-[60%] w-full h-0.5 bg-gray-700" />
              )}
              
              <div className="relative">
                <div className="flex flex-col items-center text-center">
                  {/* Number Badge */}
                  <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-6 text-2xl z-10">
                    {step.number}
                  </div>
                  
                  {/* Icon */}
                  <div className="w-20 h-20 bg-gray-800 rounded-2xl flex items-center justify-center mb-6">
                    <step.icon className="h-10 w-10 text-red-400" />
                  </div>
                  
                  {/* Content */}
                  <h3 className="text-xl mb-3">
                    {step.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});
