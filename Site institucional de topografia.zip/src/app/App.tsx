import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { ScrollToTop } from './components/ScrollToTop';
import { PageSkeleton } from './components/PageSkeleton';

// Lazy load das páginas para code splitting
const Home = lazy(() => import('./pages/Home'));
const LevantamentoTopografico = lazy(() => import('./pages/LevantamentoTopografico'));
const LocacaoDeObra = lazy(() => import('./pages/LocacaoDeObra'));
const TopografiaUsucapiaoRegularizacao = lazy(() => import('./pages/TopografiaUsucapiaoRegularizacao'));
const Georreferenciamento = lazy(() => import('./pages/Georreferenciamento'));
const NotFound = lazy(() => import('./pages/NotFound'));

// Loading fallback otimizado com skeleton
const PageLoader = () => <PageSkeleton />;

export default function App() {
  return (
    <HelmetProvider>
      <BrowserRouter>
        <div className="min-h-screen">
          <Header />
          <main id="main-content" role="main">
            <Suspense fallback={<PageLoader />}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/levantamento-topografico" element={<LevantamentoTopografico />} />
                <Route path="/locacao-de-obra" element={<LocacaoDeObra />} />
                <Route path="/topografia-usucapiao-regularizacao" element={<TopografiaUsucapiaoRegularizacao />} />
                <Route path="/georreferenciamento" element={<Georreferenciamento />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </main>
          <Footer />
          <WhatsAppButton />
          <ScrollToTop />
        </div>
      </BrowserRouter>
    </HelmetProvider>
  );
}
