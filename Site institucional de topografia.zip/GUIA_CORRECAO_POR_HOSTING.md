# 🎯 Guia de Correção NOINDEX por Provedor de Hosting

## 🔍 DIAGNÓSTICO RÁPIDO

Antes de começar, identifique onde está hospedado:

### Seu site está em qual plataforma?

- [ ] **cPanel / Hostinger / HostGator** → Ver seção A
- [ ] **Vercel** → Ver seção B
- [ ] **Netlify** → Ver seção C
- [ ] **AWS / S3 + CloudFront** → Ver seção D
- [ ] **Google Cloud / Firebase** → Ver seção E
- [ ] **Outro / Não sei** → Ver seção F

---

## 📋 SEÇÃO A: cPanel / Hostinger / HostGator

### Passo 1: Acessar File Manager

1. Entre no painel cPanel
2. Localize "File Manager" ou "Gerenciador de Arquivos"
3. Clique para abrir

### Passo 2: Navegar até a Raiz

1. No File Manager, vá para `public_html/` ou `www/`
2. Este é o diretório raiz onde seu site está hospedado

### Passo 3: Verificar index.html

1. Procure arquivo chamado `index.html`
2. Clique com botão direito → "Edit" ou "Editar"
3. Procure por linha que contenha:
   ```html
   <meta name="robots" content="noindex
   ```
4. **SE ENCONTRAR**: Delete esta linha completamente
5. Salve o arquivo

### Passo 4: Aplicar .htaccess

1. Ainda no `public_html/`, procure arquivo `.htaccess`
2. **Se NÃO existir**: Clique em "New File" e crie `.htaccess`
3. **Se JÁ existir**: Faça backup primeiro! (Download do arquivo)
4. Edite o `.htaccess` e adicione NO TOPO:

```apache
<IfModule mod_headers.c>
    # Forçar indexação
    Header unset X-Robots-Tag
    Header set X-Robots-Tag "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"
</IfModule>
```

5. Salve o arquivo

### Passo 5: Verificar Configurações do Painel

#### Hostinger:
1. Vá para "Website" → "Configurações"
2. Procure por "Visibilidade nos motores de busca"
3. **DESMARCQUE** qualquer opção que bloqueie indexação
4. Salve

#### HostGator:
1. Vá para "Software" → "SEO Tools"
2. Verifique se não há bloqueio de indexação ativado
3. Desative se houver

### Passo 6: Testar

Aguarde 5-10 minutos e execute:

```bash
curl -I https://rdstopografia.com.br | grep -i robots
```

**Resultado esperado**: 
```
X-Robots-Tag: index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1
```

---

## 📋 SEÇÃO B: Vercel

### Passo 1: Verificar Environment Variables

1. Acesse https://vercel.com/
2. Selecione seu projeto "rdstopografia"
3. Vá para **Settings** → **Environment Variables**
4. Procure por variáveis como:
   - `ROBOTS`
   - `SEO_NOINDEX`
   - `NEXT_PUBLIC_ROBOTS`
5. **DELETE** qualquer variável que esteja configurada para "noindex"

### Passo 2: Criar vercel.json

No seu projeto local, crie arquivo `vercel.json` na **raiz** (mesma pasta que package.json):

```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Robots-Tag",
          "value": "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"
        }
      ]
    }
  ]
}
```

### Passo 3: Deploy

```bash
# Se usando Git
git add vercel.json
git commit -m "fix: remover noindex"
git push

# Vercel vai fazer deploy automaticamente
```

### Passo 4: Verificar Deploy Settings

1. Em Vercel → Settings → General
2. Procure "Password Protection"
3. **DESATIVE** se estiver ativo (isso pode adicionar noindex)

### Passo 5: Testar

Aguarde o deploy finalizar (1-2 min) e teste:

```bash
curl -I https://rdstopografia.com.br | grep -i robots
```

---

## 📋 SEÇÃO C: Netlify

### Passo 1: Verificar Build Settings

1. Acesse https://app.netlify.com/
2. Selecione site "rdstopografia"
3. Vá para **Site Settings** → **Build & deploy**
4. Em "Post processing", procure "Search engine optimization"
5. **DESATIVE** qualquer opção de "Hide site from search engines"

### Passo 2: Criar netlify.toml

No seu projeto local, crie arquivo `netlify.toml` na **raiz**:

```toml
[[headers]]
  for = "/*"
  [headers.values]
    X-Robots-Tag = "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"
```

### Passo 3: Criar _headers

Também crie arquivo `public/_headers`:

```
/*
  X-Robots-Tag: index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1
```

### Passo 4: Deploy

```bash
git add netlify.toml public/_headers
git commit -m "fix: remover noindex"
git push

# Netlify vai fazer deploy automaticamente
```

### Passo 5: Verificar Password Protection

1. Em Netlify → Site Settings → Access control
2. Se "Password protection" estiver ativo, **DESATIVE**
3. Isso adiciona noindex automaticamente!

---

## 📋 SEÇÃO D: AWS S3 + CloudFront

### Passo 1: Verificar Metadata do S3

1. Acesse AWS Console → S3
2. Selecione bucket "rdstopografia"
3. Clique em `index.html`
4. Vá para aba "Metadata"
5. Procure por chave `x-amz-meta-robots`
6. **DELETE** se existir com valor "noindex"

### Passo 2: CloudFront Headers

1. Acesse CloudFront → Distributions
2. Selecione sua distribution
3. Vá para aba "Behaviors"
4. Edit behavior
5. Em "Response headers policy", selecione "Create policy"
6. Adicione custom header:
   - **Header name**: `X-Robots-Tag`
   - **Value**: `index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1`
7. Salve

### Passo 3: Invalidar Cache

```bash
aws cloudfront create-invalidation --distribution-id SEU_DISTRIBUTION_ID --paths "/*"
```

---

## 📋 SEÇÃO E: Google Cloud / Firebase

### Firebase Hosting:

1. Verifique arquivo `firebase.json`:

```json
{
  "hosting": {
    "headers": [
      {
        "source": "**",
        "headers": [
          {
            "key": "X-Robots-Tag",
            "value": "index, follow"
          }
        ]
      }
    ]
  }
}
```

2. Deploy:
```bash
firebase deploy
```

---

## 📋 SEÇÃO F: Não Sei Onde Está Hospedado

### Passo 1: Descobrir Provedor

Execute:

```bash
dig rdstopografia.com.br
```

Ou acesse: https://who.is/whois/rdstopografia.com.br

Procure por:
- **Nameservers**: Indicam onde está hospedado
  - `ns*.vercel.com` → Vercel
  - `dns*.netlify.com` → Netlify
  - `ns*.hostinger.com` → Hostinger
  - etc.

### Passo 2: Contatar Suporte

Se ainda não souber:

1. Entre em contato com quem configurou o domínio
2. Verifique e-mails de confirmação de hosting
3. Ou envie ticket para o suporte com esta mensagem:

```
Assunto: Remover tag noindex do site rdstopografia.com.br

Olá,

O Google está detectando uma meta tag ou cabeçalho HTTP "noindex" 
no meu site rdstopografia.com.br, impedindo a indexação.

Podem por favor:
1. Verificar se há cabeçalho X-Robots-Tag configurado
2. Remover qualquer bloqueio de indexação
3. Garantir que o site está visível para motores de busca

Obrigado!
```

---

## 🧪 TESTE FINAL UNIVERSAL

**Independente do provedor**, após aplicar correções:

### Teste 1: Cabeçalhos HTTP (5 min após mudança)

```bash
curl -I https://rdstopografia.com.br
```

**Procure por**:
- ✅ **BOM**: `X-Robots-Tag: index, follow`
- ❌ **RUIM**: `X-Robots-Tag: noindex`
- ⚠️ **NEUTRO**: Sem cabeçalho X-Robots-Tag

### Teste 2: Ferramenta Online (15 min após mudança)

Acesse: https://rdstopografia.com.br/diagnostico-noindex.html

Clique em todos os testes e verifique resultados.

### Teste 3: Google Search Console (1 hora após mudança)

1. Acesse https://search.google.com/search-console
2. Vá para "Inspeção de URL"
3. Digite: `https://rdstopografia.com.br`
4. Clique em "Testar URL ativo"
5. Espere o resultado
6. Se OK, clique em "Solicitar indexação"

### Teste 4: Rich Results Test (imediato)

1. Acesse: https://search.google.com/test/rich-results
2. Cole: `https://rdstopografia.com.br`
3. Clique em "Testar URL"
4. Veja se detecta `noindex` no código-fonte

---

## ⏱️ CRONOGRAMA DE RECUPERAÇÃO

Após aplicar correções:

| Tempo | Ação | Status Esperado |
|-------|------|-----------------|
| **5 min** | Teste curl | Cabeçalho correto |
| **15 min** | Teste ferramenta diagnóstico | Todos testes OK |
| **1 hora** | Solicitar indexação no GSC | Solicitação aceita |
| **24h** | Verificar GSC novamente | Status mudando |
| **48h** | Verificação final | "Indexado" no GSC |

---

## 🆘 PROBLEMAS COMUNS

### Problema: "curl não é reconhecido"

**Windows**: Use PowerShell e execute:
```powershell
Invoke-WebRequest -Uri https://rdstopografia.com.br -Method Head | Select-Object -ExpandProperty Headers
```

**OU** use: https://www.whatsmyip.org/http-headers/

### Problema: Mudanças não aparecem

1. **Limpe cache do navegador** (Ctrl+Shift+Delete)
2. **Teste em aba anônima**
3. **Aguarde propagação DNS** (até 24h em casos extremos)
4. **Verifique se fez upload correto** dos arquivos

### Problema: Arquivo .htaccess não funciona

1. Servidor pode não ser Apache
2. mod_headers pode estar desativado
3. Entre em contato com suporte do hosting

---

## ✅ CHECKLIST FINAL

Antes de solicitar indexação no Google:

- [ ] Executei `curl -I` e não aparece noindex
- [ ] Testei em https://rdstopografia.com.br/diagnostico-noindex.html
- [ ] Todos os testes passaram
- [ ] Aguardei pelo menos 15 minutos após mudanças
- [ ] Limpei cache do navegador
- [ ] Site está acessível publicamente

**Agora pode solicitar re-rastreamento no Google Search Console!**

---

**Atualizado**: 6 de março de 2026  
**Tempo estimado**: 15-30 minutos para aplicar + 24-48h para Google processar
