# Configurações de Servidor - RDS Topografia

## Cabeçalhos de Cache para Imagens (Performance)

Para melhorar o desempenho do site, configure os seguintes cabeçalhos HTTP no seu servidor:

### Apache (.htaccess)

```apache
<IfModule mod_expires.c>
  ExpiresActive On
  
  # Imagens
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType image/gif "access plus 1 year"
  ExpiresByType image/svg+xml "access plus 1 year"
  ExpiresByType image/webp "access plus 1 year"
  
  # CSS e JavaScript
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
  
  # Fontes
  ExpiresByType font/woff2 "access plus 1 year"
  ExpiresByType font/woff "access plus 1 year"
  ExpiresByType font/ttf "access plus 1 year"
</IfModule>

<IfModule mod_headers.c>
  # Cache-Control para imagens
  <FilesMatch "\.(jpg|jpeg|png|gif|svg|webp)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>
  
  # Cache-Control para CSS e JS
  <FilesMatch "\.(css|js)$">
    Header set Cache-Control "public, max-age=2592000"
  </FilesMatch>
</IfModule>
```

### Nginx

```nginx
location ~* \.(jpg|jpeg|png|gif|svg|webp)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}

location ~* \.(css|js)$ {
    expires 1M;
    add_header Cache-Control "public";
}

location ~* \.(woff2|woff|ttf)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

---

## Segurança - Desabilitar Listagem de Diretórios

### Apache (.htaccess)

```apache
# Desabilitar listagem de diretórios
Options -Indexes

# Proteger arquivos sensíveis
<FilesMatch "\.(htaccess|htpasswd|ini|log|sh|sql)$">
    Order Allow,Deny
    Deny from all
</FilesMatch>
```

### Nginx

```nginx
# Desabilitar autoindex
autoindex off;

# Bloquear acesso a arquivos sensíveis
location ~ /\. {
    deny all;
}

location ~* \.(log|ini|sh|sql)$ {
    deny all;
}
```

---

## Compressão Gzip/Brotli

### Apache (.htaccess)

```apache
<IfModule mod_deflate.c>
  # Comprimir HTML, CSS, JavaScript, Text, XML
  AddOutputFilterByType DEFLATE text/html
  AddOutputFilterByType DEFLATE text/css
  AddOutputFilterByType DEFLATE text/javascript
  AddOutputFilterByType DEFLATE application/javascript
  AddOutputFilterByType DEFLATE application/x-javascript
  AddOutputFilterByType DEFLATE text/xml
  AddOutputFilterByType DEFLATE application/xml
  AddOutputFilterByType DEFLATE application/json
</IfModule>
```

### Nginx

```nginx
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

# Brotli (se disponível)
brotli on;
brotli_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
```

---

## Headers de Segurança Adicionais

### Apache (.htaccess)

```apache
<IfModule mod_headers.c>
  # Segurança XSS
  Header set X-XSS-Protection "1; mode=block"
  
  # Prevenir MIME sniffing
  Header set X-Content-Type-Options "nosniff"
  
  # Prevenir clickjacking
  Header set X-Frame-Options "SAMEORIGIN"
  
  # Referrer Policy
  Header set Referrer-Policy "strict-origin-when-cross-origin"
  
  # Content Security Policy (ajustar conforme necessário)
  Header set Content-Security-Policy "default-src 'self' https:; script-src 'self' 'unsafe-inline' https:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: https:;"
</IfModule>
```

### Nginx

```nginx
add_header X-XSS-Protection "1; mode=block" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Content-Security-Policy "default-src 'self' https:; script-src 'self' 'unsafe-inline' https:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: https:;" always;
```

---

## Redirecionamento HTTPS Forçado

### Apache (.htaccess)

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  
  # Forçar HTTPS
  RewriteCond %{HTTPS} off
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
  
  # Forçar www (ou remover www, escolha uma opção)
  # Opção 1: Forçar www
  RewriteCond %{HTTP_HOST} !^www\. [NC]
  RewriteRule ^(.*)$ https://www.%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
  
  # Opção 2: Remover www (escolha apenas uma!)
  # RewriteCond %{HTTP_HOST} ^www\.(.+)$ [NC]
  # RewriteRule ^(.*)$ https://%1%{REQUEST_URI} [L,R=301]
</IfModule>
```

### Nginx

```nginx
# Forçar HTTPS
server {
    listen 80;
    server_name rdstopografia.com.br www.rdstopografia.com.br;
    return 301 https://$server_name$request_uri;
}

# Servidor HTTPS
server {
    listen 443 ssl http2;
    server_name rdstopografia.com.br www.rdstopografia.com.br;
    
    # Configurações SSL...
}
```

---

## React Router - SPA Configuration

Para que o React Router funcione corretamente em produção, todas as rotas devem apontar para o index.html:

### Apache (.htaccess)

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  
  # Se o arquivo ou diretório não existe, redireciona para index.html
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

### Nginx

```nginx
location / {
    try_files $uri $uri/ /index.html;
}
```

---

## Checklist de Implementação

- [ ] Configurar cabeçalhos de cache para imagens
- [ ] Desabilitar listagem de diretórios
- [ ] Ativar compressão Gzip/Brotli
- [ ] Configurar headers de segurança
- [ ] Forçar HTTPS
- [ ] Configurar redirecionamento SPA para React Router
- [ ] Testar todas as rotas após deploy
- [ ] Validar certificado SSL
- [ ] Testar performance no PageSpeed Insights
- [ ] Verificar robots.txt está acessível

---

## Ferramentas de Teste

Após implementar as configurações, teste com:

1. **PageSpeed Insights**: https://pagespeed.web.dev/
2. **Security Headers**: https://securityheaders.com/
3. **SSL Labs**: https://www.ssllabs.com/ssltest/
4. **GTmetrix**: https://gtmetrix.com/
5. **Google Search Console**: Verificar indexação e erros

---

**Nota**: Essas configurações devem ser implementadas pelo administrador do servidor ou hosting. Se estiver usando serviços como Vercel, Netlify ou AWS Amplify, muitas dessas otimizações já vêm configuradas automaticamente.
