/**
 * 🔍 RDS Topografia - SEO Checker Script
 * 
 * Execute este script no Console do navegador (F12) para verificar
 * se todas as configurações de SEO estão corretas.
 * 
 * Como usar:
 * 1. Abra o site: https://rdstopografia.com.br
 * 2. Pressione F12 (DevTools)
 * 3. Vá para a aba "Console"
 * 4. Cole este código e pressione Enter
 */

(function() {
  console.clear();
  console.log('%c🔍 RDS Topografia - Verificador SEO', 'font-size: 20px; font-weight: bold; color: #dc2626;');
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #dc2626;');
  console.log('');

  const results = {
    passed: [],
    warnings: [],
    errors: []
  };

  // 1. Verificar meta robots
  console.log('%c📋 Verificando Meta Tags...', 'font-weight: bold; font-size: 14px;');
  
  const robotsMeta = document.querySelector('meta[name="robots"]');
  if (robotsMeta) {
    const robotsContent = robotsMeta.getAttribute('content');
    if (robotsContent.includes('noindex')) {
      results.errors.push('❌ Meta robots está configurada como NOINDEX - site NÃO será indexado!');
      console.log('%c  ❌ ERRO: Meta robots = ' + robotsContent, 'color: #dc2626; font-weight: bold;');
    } else if (robotsContent.includes('index')) {
      results.passed.push('✅ Meta robots permite indexação');
      console.log('%c  ✅ Meta robots = ' + robotsContent, 'color: #16a34a;');
    }
  } else {
    results.warnings.push('⚠️ Meta robots não encontrada');
    console.log('%c  ⚠️ Meta robots não encontrada', 'color: #f59e0b;');
  }

  // 2. Verificar título
  const title = document.querySelector('title');
  if (title && title.textContent.length > 0) {
    if (title.textContent.length > 60) {
      results.warnings.push('⚠️ Título muito longo (' + title.textContent.length + ' caracteres)');
      console.log('%c  ⚠️ Título: ' + title.textContent.length + ' caracteres (ideal: 50-60)', 'color: #f59e0b;');
    } else {
      results.passed.push('✅ Título otimizado (' + title.textContent.length + ' caracteres)');
      console.log('%c  ✅ Título: "' + title.textContent + '"', 'color: #16a34a;');
    }
  } else {
    results.errors.push('❌ Título não encontrado');
    console.log('%c  ❌ Título não encontrado', 'color: #dc2626;');
  }

  // 3. Verificar descrição
  const description = document.querySelector('meta[name="description"]');
  if (description) {
    const descContent = description.getAttribute('content');
    if (descContent.length > 160) {
      results.warnings.push('⚠️ Descrição muito longa (' + descContent.length + ' caracteres)');
      console.log('%c  ⚠️ Descrição: ' + descContent.length + ' caracteres (ideal: 120-160)', 'color: #f59e0b;');
    } else if (descContent.length < 50) {
      results.warnings.push('⚠️ Descrição muito curta (' + descContent.length + ' caracteres)');
      console.log('%c  ⚠️ Descrição: ' + descContent.length + ' caracteres (mínimo: 50)', 'color: #f59e0b;');
    } else {
      results.passed.push('✅ Descrição otimizada (' + descContent.length + ' caracteres)');
      console.log('%c  ✅ Descrição: ' + descContent.length + ' caracteres', 'color: #16a34a;');
    }
  } else {
    results.errors.push('❌ Meta descrição não encontrada');
    console.log('%c  ❌ Meta descrição não encontrada', 'color: #dc2626;');
  }

  // 4. Verificar canonical
  const canonical = document.querySelector('link[rel="canonical"]');
  if (canonical) {
    results.passed.push('✅ URL canônica configurada');
    console.log('%c  ✅ Canonical: ' + canonical.getAttribute('href'), 'color: #16a34a;');
  } else {
    results.warnings.push('⚠️ URL canônica não encontrada');
    console.log('%c  ⚠️ URL canônica não encontrada', 'color: #f59e0b;');
  }

  // 5. Verificar Open Graph
  console.log('');
  console.log('%c📱 Verificando Open Graph (Facebook/WhatsApp)...', 'font-weight: bold; font-size: 14px;');
  
  const ogTitle = document.querySelector('meta[property="og:title"]');
  const ogDescription = document.querySelector('meta[property="og:description"]');
  const ogImage = document.querySelector('meta[property="og:image"]');
  const ogUrl = document.querySelector('meta[property="og:url"]');

  if (ogTitle && ogDescription && ogImage && ogUrl) {
    results.passed.push('✅ Open Graph completo');
    console.log('%c  ✅ Open Graph configurado corretamente', 'color: #16a34a;');
  } else {
    results.warnings.push('⚠️ Open Graph incompleto');
    console.log('%c  ⚠️ Open Graph incompleto:', 'color: #f59e0b;');
    if (!ogTitle) console.log('    - og:title ausente');
    if (!ogDescription) console.log('    - og:description ausente');
    if (!ogImage) console.log('    - og:image ausente');
    if (!ogUrl) console.log('    - og:url ausente');
  }

  // 6. Verificar Schema.org JSON-LD
  console.log('');
  console.log('%c🏢 Verificando Schema.org JSON-LD...', 'font-weight: bold; font-size: 14px;');
  
  const schemas = document.querySelectorAll('script[type="application/ld+json"]');
  if (schemas.length > 0) {
    results.passed.push('✅ Schema.org implementado (' + schemas.length + ' schemas)');
    console.log('%c  ✅ ' + schemas.length + ' schema(s) JSON-LD encontrado(s)', 'color: #16a34a;');
    schemas.forEach((schema, i) => {
      try {
        const data = JSON.parse(schema.textContent);
        console.log('    Schema ' + (i+1) + ': ' + (data['@type'] || 'Unknown'));
      } catch(e) {
        results.errors.push('❌ Schema ' + (i+1) + ' com JSON inválido');
        console.log('%c    ❌ Schema ' + (i+1) + ' com JSON inválido', 'color: #dc2626;');
      }
    });
  } else {
    results.warnings.push('⚠️ Schema.org não encontrado');
    console.log('%c  ⚠️ Nenhum schema JSON-LD encontrado', 'color: #f59e0b;');
  }

  // 7. Verificar hierarquia de headings
  console.log('');
  console.log('%c📝 Verificando Hierarquia de Headings...', 'font-weight: bold; font-size: 14px;');
  
  const h1s = document.querySelectorAll('h1');
  if (h1s.length === 0) {
    results.errors.push('❌ Nenhum H1 encontrado');
    console.log('%c  ❌ Nenhum H1 encontrado na página', 'color: #dc2626;');
  } else if (h1s.length > 1) {
    results.warnings.push('⚠️ Múltiplos H1s encontrados (' + h1s.length + ')');
    console.log('%c  ⚠️ ' + h1s.length + ' H1s encontrados (ideal: 1)', 'color: #f59e0b;');
  } else {
    results.passed.push('✅ H1 único e correto');
    console.log('%c  ✅ H1: "' + h1s[0].textContent.trim().substring(0, 60) + '..."', 'color: #16a34a;');
  }

  const h2s = document.querySelectorAll('h2').length;
  const h3s = document.querySelectorAll('h3').length;
  console.log('  📊 Headings: H1(' + h1s.length + '), H2(' + h2s + '), H3(' + h3s + ')');

  // 8. Verificar imagens
  console.log('');
  console.log('%c🖼️ Verificando Imagens...', 'font-weight: bold; font-size: 14px;');
  
  const images = document.querySelectorAll('img');
  let imagesWithoutAlt = 0;
  images.forEach(img => {
    if (!img.hasAttribute('alt') || img.getAttribute('alt').trim() === '') {
      imagesWithoutAlt++;
    }
  });

  if (imagesWithoutAlt > 0) {
    results.warnings.push('⚠️ ' + imagesWithoutAlt + ' imagens sem atributo alt');
    console.log('%c  ⚠️ ' + imagesWithoutAlt + ' de ' + images.length + ' imagens sem alt', 'color: #f59e0b;');
  } else if (images.length > 0) {
    results.passed.push('✅ Todas as imagens com alt');
    console.log('%c  ✅ ' + images.length + ' imagens, todas com alt', 'color: #16a34a;');
  }

  // 9. Verificar links internos
  console.log('');
  console.log('%c🔗 Verificando Links...', 'font-weight: bold; font-size: 14px;');
  
  const links = document.querySelectorAll('a[href]');
  const internalLinks = Array.from(links).filter(a => {
    const href = a.getAttribute('href');
    return href && (href.startsWith('/') || href.includes('rdstopografia.com.br'));
  });
  const externalLinks = links.length - internalLinks.length;

  console.log('  📊 Links internos: ' + internalLinks.length);
  console.log('  📊 Links externos: ' + externalLinks);
  results.passed.push('✅ ' + links.length + ' links encontrados');

  // 10. Verificar performance
  console.log('');
  console.log('%c⚡ Verificando Performance...', 'font-weight: bold; font-size: 14px;');
  
  if ('performance' in window && performance.timing) {
    const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
    if (loadTime < 3000) {
      results.passed.push('✅ Tempo de carregamento rápido (' + (loadTime/1000).toFixed(2) + 's)');
      console.log('%c  ✅ Tempo de carregamento: ' + (loadTime/1000).toFixed(2) + 's', 'color: #16a34a;');
    } else {
      results.warnings.push('⚠️ Tempo de carregamento lento (' + (loadTime/1000).toFixed(2) + 's)');
      console.log('%c  ⚠️ Tempo de carregamento: ' + (loadTime/1000).toFixed(2) + 's (ideal: < 3s)', 'color: #f59e0b;');
    }
  }

  // RESUMO FINAL
  console.log('');
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #dc2626;');
  console.log('%c📊 RESUMO DA VERIFICAÇÃO', 'font-size: 16px; font-weight: bold;');
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #dc2626;');
  console.log('');

  if (results.passed.length > 0) {
    console.log('%c✅ PASSOU (' + results.passed.length + ')', 'color: #16a34a; font-weight: bold; font-size: 14px;');
    results.passed.forEach(item => console.log('  ' + item));
    console.log('');
  }

  if (results.warnings.length > 0) {
    console.log('%c⚠️ AVISOS (' + results.warnings.length + ')', 'color: #f59e0b; font-weight: bold; font-size: 14px;');
    results.warnings.forEach(item => console.log('  ' + item));
    console.log('');
  }

  if (results.errors.length > 0) {
    console.log('%c❌ ERROS CRÍTICOS (' + results.errors.length + ')', 'color: #dc2626; font-weight: bold; font-size: 14px;');
    results.errors.forEach(item => console.log('  ' + item));
    console.log('');
  }

  // Pontuação final
  const totalTests = results.passed.length + results.warnings.length + results.errors.length;
  const score = Math.round((results.passed.length / totalTests) * 100);
  
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #dc2626;');
  
  if (score >= 90) {
    console.log('%c🎉 PONTUAÇÃO SEO: ' + score + '% - EXCELENTE!', 'color: #16a34a; font-weight: bold; font-size: 16px;');
  } else if (score >= 70) {
    console.log('%c👍 PONTUAÇÃO SEO: ' + score + '% - BOM', 'color: #f59e0b; font-weight: bold; font-size: 16px;');
  } else {
    console.log('%c⚠️ PONTUAÇÃO SEO: ' + score + '% - PRECISA MELHORAR', 'color: #dc2626; font-weight: bold; font-size: 16px;');
  }

  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #dc2626;');
  console.log('');
  
  if (results.errors.length === 0) {
    console.log('%c✅ Site está pronto para indexação pelo Google!', 'color: #16a34a; font-weight: bold; font-size: 14px;');
  } else {
    console.log('%c❌ Corrija os erros críticos antes de solicitar indexação!', 'color: #dc2626; font-weight: bold; font-size: 14px;');
  }
  
  console.log('');
  console.log('📚 Documentação completa: /CORRECAO_INDEXACAO_GOOGLE.md');
  console.log('🔗 Solicitar indexação: https://search.google.com/search-console');
  console.log('');

  return {
    score,
    passed: results.passed.length,
    warnings: results.warnings.length,
    errors: results.errors.length,
    details: results
  };
})();
